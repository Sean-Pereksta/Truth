@echo off
setlocal
call "%~dp0server\Start Acorn Rally.cmd"
