// Sample the same simulation geometry used by the race engine for editor import.
const fs = require('node:fs');
const path = require('node:path');
const sim = require(path.resolve(process.argv[2]));
const convert = p => [p.x/2, p.y/2, p.z/2, p.w/2].map(v=>Number(v.toFixed(5)));
const routes = Array.from({length:8}, (_, index) => {
  const c = sim.track(index);
  const pickups = sim.create({trackIndex:index}).pickups;
  return {
    name:c.name, points:c.points.map(convert), bridge:c.bridgeS,
    branchA:c.branchA, branchB:c.branchB,
    branchPoints:Array.from({length:101}, (_, t) => convert(sim.sample(c,
      (c.branchA+(c.branchB-c.branchA)*t/100)*c.length,0,true))),
    pickups:[...new Set(pickups.map(p=>p.s/c.length))], pickupLanes:[...new Set(pickups.map(p=>p.x/2))],
    grid:sim.create({trackIndex:index}).racers.map(r=>[r.s/c.length,r.x/2])
  };
});
fs.writeFileSync(process.argv[3], JSON.stringify(routes));
