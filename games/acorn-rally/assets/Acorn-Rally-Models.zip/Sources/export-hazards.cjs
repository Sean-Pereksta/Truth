// node export-hazards.cjs <game directory> <existing Workshop> <overlay directory>
'use strict';
const fs=require('node:fs'),path=require('node:path');
const [game,kit,out]=process.argv.slice(2).map(v=>path.resolve(v));
global.window=global;global.AcornSim=require(path.join(game,'race-sim.js'));
global.AcornHazards=require(path.join(game,'hazards.js'));global.AcornRig=require(path.join(game,'kart-rig.js'));
global.AcornRamps=require(path.join(game,'ramps.js'));require(path.join(game,'ramp-art.js'));
require(path.join(game,'race-world.js'));require(path.join(game,'course-art.js'));
const {Mesh,matrix}=AcornWorld, library=AcornCourseArt.meshes(Mesh);
const pad=(buffer,byte=0)=>Buffer.concat([buffer,Buffer.alloc((4-buffer.length%4)%4,byte)]);
function readDocument(file){
  if(!file)return {g:{asset:{version:'2.0',generator:'Acorn Rally Workshop'},scene:0,scenes:[{nodes:[]}],nodes:[],materials:[],accessors:[],bufferViews:[],meshes:[],buffers:[{}]},bin:Buffer.alloc(0)};
  const f=fs.readFileSync(file),size=f.readUInt32LE(12),g=JSON.parse(f.subarray(20,20+size));
  return {g,bin:f.subarray(size+28,size+28+g.buffers[0].byteLength)};
}
function chunk(data,type){const h=Buffer.alloc(8);h.writeUInt32LE(data.length);h.writeUInt32LE(type,4);return Buffer.concat([h,data]);}
function saveDocument(file,g,bin){
  const j=chunk(pad(Buffer.from(JSON.stringify(g)),32),0x4e4f534a),b=chunk(pad(bin),0x004e4942),head=Buffer.alloc(12);
  head.write('glTF');head.writeUInt32LE(2,4);head.writeUInt32LE(12+j.length+b.length,8);
  fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,Buffer.concat([head,j,b]));
}
function insert(file,destination,meta,anchor,stamps){
  const {g,bin}=readDocument(file),buffers=[pad(bin)],parts=new Map();
  let bytes=buffers[0].length;
  function accessor(values,bounds){
    const buffer=Buffer.from(Float32Array.from(values).buffer),view=g.bufferViews.length;
    g.bufferViews.push({buffer:0,byteOffset:bytes,byteLength:buffer.length,target:34962});buffers.push(buffer);bytes+=buffer.length;
    const a={bufferView:view,componentType:5126,count:values.length/3,type:'VEC3'};
    if(bounds){a.min=[Infinity,Infinity,Infinity];a.max=[-Infinity,-Infinity,-Infinity];for(let j=0;j<values.length;j++){a.min[j%3]=Math.min(a.min[j%3],values[j]);a.max[j%3]=Math.max(a.max[j%3],values[j]);}}
    return g.accessors.push(a)-1;
  }
  function meshIndex(name,opacity){
    const key=name+'-'+Math.round(opacity*100);
    if(parts.has(key))return parts.get(key);
    const data=library[name].data,positions=[],normals=[],colors=[];
    for(let i=0;i<data.length;i+=10){
      positions.push(...data.slice(i,i+3));normals.push(...data.slice(i+3,i+6));
      for(const c of data.slice(i+6,i+9))colors.push(c<.04045?c/12.92:((c+.055)/1.055)**2.4);
    }
    const material=g.materials.push({name,alphaMode:opacity<.995?'BLEND':'OPAQUE',doubleSided:true,
      pbrMetallicRoughness:{baseColorFactor:[1,1,1,opacity],roughnessFactor:.77,metallicFactor:0}})-1;
    const primitives=[{attributes:{POSITION:accessor(positions,true),NORMAL:accessor(normals),COLOR_0:accessor(colors)},material}];
    const index=g.meshes.push({name,primitives})-1;parts.set(key,index);return index;
  }
  const assembly={name:meta.name,children:[],extras:meta};
  if(file)assembly.translation=anchor.map(x=>x/2);
  const root=g.nodes.push(assembly)-1;g.scenes[g.scene??0].nodes.push(root);
  for(const {name,at,heading,size,opacity,roll,pitch,stretch} of stamps){
    const m=matrix(...at.map((v,i)=>(v-anchor[i])/2),heading,size/2,roll,pitch);
    for(let j=0;j<3;j++)for(let k=0;k<3;k++)m[4*j+k]*=stretch[j];
    assembly.children.push(g.nodes.push({name,mesh:meshIndex(name,opacity),matrix:Array.from(m)})-1);
  }
  g.buffers[0].byteLength=bytes;saveDocument(destination,g,Buffer.concat(buffers));
}
for(const [id,cfg] of AcornHazards.routes.entries()){
  const course=AcornSim.track(id),time=(cfg.warn+cfg.live*.50-cfg.offset+cfg.period)%cfg.period;
  const sampled=AcornHazards.sample(course,time),origin=AcornSim.sample(course,cfg.u*course.length,0,Boolean(cfg.branch));
  const anchor=[origin.x,origin.y,origin.z],stamps=[];
  AcornCourseArt.scene(sampled,time,(name,s,x,height,yaw,size,opacity,roll,pitch,stretch,branch)=>{
    const p=AcornSim.sample(course,s,x,branch);
    stamps.push({name,at:[p.x,p.y+height,p.z],heading:Math.atan2(p.tx,p.tz)+yaw,size,opacity,roll,pitch,stretch});
  });
  if(stamps.length===0)throw Error('Missing geometry for '+cfg.name);
  const metadata={...cfg,tip:AcornHazards.tips[id],previewTime:time,placementUnits:'runtime metres',route:cfg.branch?'shortcut':'main'};
  insert(null,path.join(out,'Prefabs','Hazards',cfg.name+'.glb'),metadata,anchor,stamps);
  const relative=path.join('Courses',course.name),base=path.join(kit,relative);
  insert(base+'.glb',path.join(out,relative+'.glb'),metadata,anchor,stamps);
  const route=JSON.parse(fs.readFileSync(base+'.json'));route.courseHazard=metadata;route.ramps=[];
  for(const ramp of AcornRamps.list(course)){
    const point=AcornSim.baseSample(course,ramp.lipS,ramp.lane,ramp.branch);
    const pivot=[point.x,point.y,point.z],part=AcornRampArt.rampMesh(Mesh,course,ramp);
    for(let j=0;j<part.data.length;j+=10)for(let axis=0;axis<3;axis++)part.data[j+axis]-=pivot[axis];
    library[ramp.id]=part;
    const piece={name:ramp.id,at:pivot,heading:0,size:1,opacity:1,roll:0,pitch:0,stretch:[1,1,1]};
    const rampMeta={...ramp,kind:'Driveable ramp',placementUnits:'runtime metres'};
    insert(null,path.join(out,'Prefabs','Ramps',ramp.id+'.glb'),rampMeta,pivot,[piece]);
    const assembled=path.join(out,relative+'.glb');insert(assembled,assembled,rampMeta,pivot,[piece]);
    route.ramps.push(rampMeta);
  }
  fs.writeFileSync(path.join(out,relative+'.json'),JSON.stringify(route));
  console.log(course.name+' · '+cfg.name+' · '+stamps.length+' editable pieces');
}
