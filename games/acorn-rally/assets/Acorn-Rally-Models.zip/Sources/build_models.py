"""Build Acorn Rally's editable, instanced glTF 2.0 scene kit.

Requires Python 3, Pillow, and NumPy. Run with an output directory argument.
All coordinates are in kart lengths. Y is up, +Z is the kart's nose.
"""
from pathlib import Path
import argparse
import base64
import copy
import io
import json
import math
import os
import random
import struct
from functools import lru_cache

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageOps


TAU = 2 * math.pi
PAINTS = ["#e65a22", "#28638e", "#9773c3", "#258771","#dfad36","#b93d38","#62794c","#365dba"]
NAMES = ["Nib", "Bristle", "Clover", "Tumble","Hazel","Ember","Flint","Mica"]
FURS = ["#a3663e", "#746f70", "#d8c4a5", "#aa582c","#937047","#c96830","#656a62","#454344"]
SPECIES=["mouse","rat","rabbit","squirrel","hedgehog","fox","badger","mole"]
palette = {
    "oak": "#a97443", "bark": "#795541", "soil": "#866247",
    "sand": "#d89965", "salt": "#d0d9d6", "basalt": "#545963",
    "brick": "#ae6f57", "grass": "#45804c", "stone": "#87928c",
    "plank": "#96734e", "rubber": "#292b2d", "weave": "#ad8f67"
}
palette.update({
    **dict(zip(FURS, FURS)), **dict(zip(PAINTS,PAINTS)),
    **{f"jacket{i}":c for i,c in enumerate(PAINTS)},
    "lightfur0":"#e6bc8c","lightfur1":"#d4c8b5","lightfur2":"#f0ddbb","lightfur3":"#efbd86",
    "leather":"#65402b","scarf":"#dfcb9a","ear":"#db9a8e","cork":"#af845b","reed":"#ba9565",
    "brass":"#ad8b50","steel":"#9ca6a7","iron":"#4d5354","blackleather":"#3d332b",
    "headlamp":"#efe4b9","glass":"#41656e","rubberwall":"#323238",
    "plate0":"#f1dcb3","plate1":"#e6dacb","plate2":"#efdfc6","plate3":"#e6dbbf",
    "reg0":"#ebe0bb","reg1":"#ebe0bb","reg2":"#ebe0bb","reg3":"#ebe0bb","checker":"#d2c4ad",
    "iris0":"#764623","iris1":"#8c7150","iris2":"#816047","iris3":"#86502d",
    "stitch":"#b7966e","rope":"#9f875b","leafpod":"#a87942"
})
palette.update({**{f"head{i}":c for i,c in enumerate(FURS)},
    **{f"plate{i}":"#e7dcbd" for i in range(4,8)},**{f"reg{i}":"#e7dcbd" for i in range(4,8)},
    **{f"iris{i}":"#785330" for i in range(4,8)},"lightfur4":"#d8bc92","lightfur5":"#f4dfc4",
    "lightfur6":"#e1decc","lightfur7":"#af9a90","quill":"#735d48","rosepaw":"#bd8b8c","goldglass":"#aa8145"})
TEXTURES = {}
TEXDIR = None


def rgb(color):
    return tuple(int(color.lstrip("#")[i:i+2], 16)/255 for i in (0, 2, 4))


def maps(directory):
    """Generate periodic tileable material maps from a seeded height field."""
    global TEXDIR
    TEXDIR = directory
    directory.mkdir(parents=True, exist_ok=True)
    size = 256
    y, x = np.mgrid[0:size, 0:size] * TAU / size
    for n, (key, col) in enumerate(palette.items()):
        rng = np.random.default_rng(60012+n)
        h = np.zeros((size, size))
        for frequency, amplitude in ((1, .24),(3,.14),(7,.09),(15,.035)):
            for i in range(3):
                fx, fy = rng.integers(0, frequency+1, size=2)
                h += amplitude*np.sin(max(1,fx)*x + fy*y + rng.uniform(0,TAU))
        if key in ("oak", "bark", "plank"):
            h = .25*h+.25*np.cos(9*x+.7*np.sin(2*y)+h*2)+.15*np.sin(34*x+h)
            if key == "bark":
                h -= .43*np.exp(-15*np.abs(np.sin(6*x+.7*h)))
            if key == "plank":
                h -= .85*np.exp(-100*np.abs(np.sin(2*x)))
        elif key == "brick":
            h = .22*h-.64*np.maximum(np.exp(-25*np.abs(np.sin(3*y))),
                   np.exp(-35*np.abs(np.sin(2*x+np.floor(y*3/math.pi)*math.pi/2))))
        elif key == "salt":
            h = .25*h+.3*np.exp(-15*np.abs(np.sin(2*x+h)+np.cos(3*y)))
        elif key == "rubber":
            h = .25*h+.4*(np.sin(7*x+np.abs(np.sin(2*y))*4)>.6)
        elif key == "weave":
            h = .2*h+.23*np.sin(24*x)*np.cos(24*y)
        else:
            h += rng.normal(0,.10,size=(size,size))
        base = np.array(rgb(col))*255
        color = np.clip(base[None,None,:]*(1+.32*h[...,None]), 0,255).astype("uint8")
        artist=Path(__file__).parent/"surface-art"
        sourcefur=[0,1,2,3,0,3,1,1];sourcecloth=[0,1,2,3,0,0,3,1]
        arts={**{c:f"fur-{sourcefur[i]}.png" for i,c in enumerate(FURS)},
              **{f"lightfur{i}":f"fur-{sourcefur[i]}.png" for i in range(8)},
              **{f"head{i}":f"fur-{sourcefur[i]}.png" for i in range(8)},
              **{f"jacket{i}":f"cloth-{sourcecloth[i]}.png" for i in range(8)},
              "quill":"fur-0.png","rosepaw":"ear.png",
              "oak":"oak.png","plank":"oak.png","reed":"oak.png","leafpod":"oak.png","cork":"cork.png",
              "leather":"leather.png","blackleather":"leather.png","scarf":"wool.png","ear":"ear.png",
              "brass":"brass.png","steel":"tin.png","iron":"tin.png","rubber":"rubber.png","rubberwall":"rubber.png"}
        source=artist/arts.get(key,"missing.png")
        if source.exists():
            im=Image.open(source).convert("RGB").resize((size,size),Image.Resampling.LANCZOS)
            raw=np.array(im,dtype=float)
            isfur=key in FURS or key.startswith(("head","lightfur")) or key=="ear"
            if isfur or key.startswith("jacket") or key in ("scarf","rubber","rubberwall","cork","leather"):
                # Fine fibres and fine-weave cloth must read at the scale of the character.
                repeatx=5 if isfur else 3;repeaty=4 if isfur else 3
                tile=np.asarray(im.resize((math.ceil(size/repeatx),math.ceil(size/repeaty)),Image.Resampling.LANCZOS),dtype=float)
                raw=np.tile(tile,(repeaty,repeatx,1))[:size,:size]
            avg=raw.mean(axis=(0,1))
            contrast=.46 if isfur else .64 if key.startswith("jacket") else .77
            color=np.clip(base[None,None,:]+(raw-avg[None,None,:])*contrast,0,255).astype("uint8")
            h=(color.astype(float).mean(axis=2)-base.mean())/105.
            if key.startswith("head"):
                i=int(key[-1]);a=x-math.pi;lat=.5*math.pi-y/2
                mm=np.exp(-((a/(1.08 if i!=5 else 1.4))**4)-(((lat+.34)/.46)**4))
                light=np.array(rgb(palette[f"lightfur{i}"]))*255
                blend=(.62*mm)[:,:,None]
                color=color.astype(float)*(1-blend)+(light[None,None,:]+(raw-avg)*.24)*blend
                if i==6:
                    white=np.exp(-((a/.29)**2))+.86*np.exp(-((np.abs(a)-1.27)/.33)**2)
                    white+=.88*np.exp(-((np.abs(a)-math.pi)/.27)**2)*np.clip((lat+.25)*2.8,0,1)
                    white=np.clip(white,0,1)[:,:,None]
                    dark=np.clip(1.15*np.exp(-((abs(a)-.64)/.34)**4),0,1)[:,:,None]
                    color=color*(1-dark)+np.array([47,48,45])*dark
                    color=color*(1-white)+(np.array([217,212,192])+(raw-avg)*.3)*white
                color=np.clip(color,0,255).astype("uint8")
        if key in PAINTS:
            # Painted patina and irregular fine chips in the clear coat.
            mask=(rng.random((size,size))>.9978)
            color=np.clip(base*(1+.08*h[:,:,None]),0,255).astype('uint8')
            color[mask]=[186,163,120]
        if key.startswith(("plate","reg","iris")) or key=="checker":
            art=Image.new("RGB",(size,size),tuple(int(v) for v in base));d=ImageDraw.Draw(art)
            if key.startswith(("plate","reg")):
                i=int(key[-1]);regular=key.startswith("reg")
                d.rounded_rectangle((3,3,252,252),radius=19,outline="#383e36",width=7)
                d.rounded_rectangle((14,14,241,241),radius=13,outline=PAINTS[i],width=5)
                def fitted(value,maxwidth,px):
                    fp=next((p for p in [Path(__file__).parent/'Rally-Bold.ttf',Path('C:/Windows/Fonts/ariblk.ttf'),Path('C:/Windows/Fonts/arialbd.ttf')] if p.exists()),None)
                    while px>10:
                        f=ImageFont.truetype(str(fp),px) if fp else ImageFont.load_default(size=px)
                        if d.textlength(value,font=f)<=maxwidth:return f
                        px-=1
                    return f
                a=["07","13","21","42","28","56","64","88"][i]
                d.text((128,143),a,anchor='mm',fill="#263b38",font=fitted(a,209,160))
                d.text((128,44),NAMES[i].upper(),anchor='mm',fill="#455242",font=fitted(NAMES[i].upper(),165,35))
                for cx in (21,235):
                    for cy in (21,235):d.ellipse((cx-4,cy-4,cx+4,cy+4),fill="#735f47")
            elif key=="checker":
                for ry in range(8):
                    for rx in range(8):
                        d.rectangle((rx*32,ry*32,(rx+1)*32,(ry+1)*32),fill=("#ece3cd" if (rx+ry)%2 else "#343833"))
            else:
                # Radial flecks and a dark limbal ring are visible through the cornea.
                yy,xx=np.mgrid[0:size,0:size];rr=np.hypot(xx-size/2,yy-size/2)/(size*.5);ang=np.arctan2(yy-size/2,xx-size/2)
                intens=(.83+.15*np.sin(ang*85+2*np.sin(ang*14)+rr*9))*(1-.5*np.clip((rr-.75)*4,0,1))
                art=Image.fromarray(np.clip(base*intens[:,:,None],0,255).astype("uint8"))
            color=np.array(art);h=np.zeros_like(h)
        strength=.12 if key in ("glass","goldglass","headlamp") else .55 if key.startswith(("head","lightfur","jacket")) or key in FURS else 1.1
        dx = (np.roll(h, -1, axis=1)-np.roll(h,1,axis=1))*strength
        dy = (np.roll(h, -1, axis=0)-np.roll(h,1,axis=0))*strength
        norm = np.stack((-dx, -dy, np.ones_like(dx)),axis=-1)
        norm /= np.sqrt((norm*norm).sum(axis=-1))[...,None]
        normal = np.rint((norm*.5+.5)*255).astype("uint8")
        rough = np.zeros_like(color)
        rough[:,:,0] = 255
        rough_base=56 if key.startswith("iris") or key in ("glass","headlamp") else 109 if key in (*PAINTS,"steel","brass") else 183
        rough[:,:,1] = np.clip(rough_base+19*h,45,250).astype("uint8")
        rough[:,:,2]=int(255*(.72 if key in ("steel","brass","iron") else .12 if key in PAINTS else 0.))
        for suffix, data in (("basecolor",color),("normal",normal),("occlusion-roughness-metallic",rough)):
            stream = io.BytesIO()
            Image.fromarray(data).save(stream,format="PNG",optimize=True)
            TEXTURES[(key,suffix)] = stream.getvalue()
            # Basecolour JPEG keeps the workshop portable. Normal and ORM stay lossless.
            if suffix=="basecolor":Image.fromarray(data).save(directory/f"{key}-{suffix}.jpg",quality=91,subsampling=0,optimize=True)
            else:(directory/f"{key}-{suffix}.png").write_bytes(stream.getvalue())


def rot(axis, angle):
    axis = np.array(axis,dtype=float)
    axis /= max(1e-10,np.linalg.norm(axis))
    return [*map(float,axis*math.sin(angle/2)), math.cos(angle/2)]


def from_y(vec):
    v = np.array(vec,dtype=float)
    v /= max(np.linalg.norm(v), 1e-10)
    if v[1] < -.99999:
        return [1.,0.,0.,0.]
    q = [v[2], 0., -v[0], 1+v[1]]
    return (np.array(q)/np.linalg.norm(q)).tolist()


@lru_cache(maxsize=None)
def revolution(profile, sides):
    positions, normals, uvs, indices = [], [], [], []
    for j,(h,radius) in enumerate(profile):
        p0,p1=profile[max(0,j-1)],profile[min(len(profile)-1,j+1)]
        slope = p0[1]-p1[1]; height = p1[0]-p0[0]
        divisor = max(.00001,math.hypot(slope,height))
        for i in range(sides+1):
            a = i*TAU/sides
            c,s=math.cos(a),math.sin(a)
            positions.append([radius*c,h,radius*s])
            normals.append([height*c/divisor,slope/divisor,height*s/divisor])
            uvs.append([i/sides,j/(len(profile)-1)])
            if j and i:
                d=j*(sides+1)+i; a0=d-sides-2; b=a0+1;c0=d-1
                indices.extend([a0,c0,b,b,c0,d])
    return positions,normals,uvs,indices


SHAPES = {
    "sphere":tuple((math.sin(-math.pi/2+i*math.pi/12),max(0,math.cos(-math.pi/2+i*math.pi/12))) for i in range(13)),
    "cylinder":((-.5,0),(-.5,.94),(-.46,1),(.46,1),(.5,.94),(.5,0)),
    "wheel":((-.5,0),(-.5,.74),(-.46,.88),(-.33,1),(.33,1),(.46,.88),(.5,.74),(.5,0)),
    "acorn":((-.65,0),(-.59,.19),(-.34,.53),(0,.69),(.26,.59),(.32,0)),
    "cap":((-.15,0),(-.15,.69),(0,.75),(.26,.62),(.41,.28),(.42,0)),
    "cone":((-.5,0),(-.5,1),(-.44,1),(.5,0)),
    "rock":((-.48,0),(-.45,.88),(-.13,1),(.24,.85),(.5,.4),(.51,0))
}


@lru_cache(maxsize=None)
def cube():
    p,n,uv,idx=[],[],[],[]
    faces=[((1,0,0),(0,1,0),(0,0,1)),((-1,0,0),(0,1,0),(0,0,-1)),
           ((0,1,0),(0,0,1),(1,0,0)),((0,-1,0),(0,0,1),(-1,0,0)),
           ((0,0,1),(1,0,0),(0,1,0)),((0,0,-1),(-1,0,0),(0,1,0))]
    for normal,u,v in faces:
        start=len(p)
        for a,b in ((-1,-1),(1,-1),(1,1),(-1,1)):
            p.append([(normal[i]+a*u[i]+b*v[i])/2 for i in range(3)])
            n.append(normal);uv.append([(a+1)/2,(b+1)/2])
        idx.extend([start,start+1,start+2,start,start+2,start+3])
    return p,n,uv,idx


class Scene:
    def __init__(self,name):
        self.buf=bytearray()
        self.g={"asset":{"version":"2.0","generator":"Acorn Rally procedural workshop"},
            "scene":0,"scenes":[{"name":name,"nodes":[]}],
            "nodes":[],"meshes":[],"materials":[],"accessors":[],"bufferViews":[],"buffers":[]}
        self.materials={}; self.geometry={}; self.meshes={};self.textures={}
    def view(self, data, target=None):
        while len(self.buf)%4:self.buf.append(0)
        view={"buffer":0,"byteOffset":len(self.buf),"byteLength":len(data)}
        if target:view["target"]=target
        self.buf.extend(data);self.g["bufferViews"].append(view)
        return len(self.g["bufferViews"])-1
    def accessor(self,a,kind,component=5126,target=None):
        arr=np.asarray(a, dtype={5126:"<f4",5123:"<u2",5125:"<u4"}[component])
        acc={"bufferView":self.view(arr.tobytes(),target),"componentType":component,
             "count":len(arr),"type":kind}
        if component==5126:
            ar=arr.reshape(len(arr),-1)
            acc.update(min=ar.min(axis=0).tolist(),max=ar.max(axis=0).tolist())
        self.g["accessors"].append(acc);return len(self.g["accessors"])-1
    def texture(self,key,suffix):
        pair=(key,suffix)
        if pair in self.textures:return self.textures[pair]
        imgs=self.g.setdefault("images",[]);texs=self.g.setdefault("textures",[])
        imgs.append({"name":f"{key} {suffix}","uri":f"{key}-{suffix}.png"})
        texs.append({"source":len(imgs)-1})
        idx=len(texs)-1;self.textures[pair]=idx
        return idx
    def mat(self,key):
        if key in self.materials:return self.materials[key]
        if key in palette:
            base={"baseColorTexture":{"index":self.texture(key,"basecolor")},
                  "metallicFactor":1.,"roughnessFactor":1.,
                  "metallicRoughnessTexture":{"index":self.texture(key,"occlusion-roughness-metallic")}}
            mat={"normalTexture":{"index":self.texture(key,"normal"),"scale":.65}}
        else:
            metal=key.startswith("metal:")
            col=key.split(":")[-1]
            base={"baseColorFactor":[*rgb(col),1.],"metallicFactor":.55 if metal else .03,
                  "roughnessFactor":.34 if metal else .71}
            mat={}
        mat.update(name=key,pbrMetallicRoughness=base,doubleSided=True)
        self.g["materials"].append(mat);idx=len(self.g["materials"])-1
        self.materials[key]=idx;return idx
    def mesh(self,shape,mat,sides=16,geo=None):
        mk=(shape,mat,sides)
        if mk in self.meshes:return self.meshes[mk]
        gk=(shape,sides)
        if gk not in self.geometry:
            p,n,uv,idx=geo if geo else (cube() if shape=="box" else revolution(SHAPES[shape],sides))
            attrs={"POSITION":self.accessor(p,"VEC3",target=34962),"NORMAL":self.accessor(n,"VEC3",target=34962),
                   "TEXCOORD_0":self.accessor(uv,"VEC2",target=34962)}
            self.geometry[gk]=(attrs,self.accessor(idx,"SCALAR",5123 if len(p)<65536 else 5125,34963))
        attrs,idx=self.geometry[gk]
        self.g["meshes"].append({"name":f"{shape} · {mat}","primitives":[{"attributes":attrs,"indices":idx,"material":self.mat(mat)}]})
        index=len(self.g["meshes"])-1; self.meshes[mk]=index;return index
    def node(self,name,parent=None,pos=None,scale=None,q=None,mesh=None,extras=None):
        obj={"name":name}
        if pos is not None:obj["translation"]=list(map(float,pos))
        if scale is not None:obj["scale"]=list(map(float,scale))
        if q is not None:obj["rotation"]=list(map(float,q))
        if mesh is not None:obj["mesh"]=mesh
        if extras:obj["extras"]=extras
        index=len(self.g['nodes']);self.g["nodes"].append(obj)
        if parent is None:self.g['scenes'][0]['nodes'].append(index)
        else:self.g['nodes'][parent].setdefault('children',[]).append(index)
        return index
    def part(self,name,parent,shape,mat,pos,scale,q=None,sides=16):
        return self.node(name,parent,pos,scale,q,self.mesh(shape,mat,sides))
    def bar(self,name,parent,mat,p1,p2,r,sides=10):
        a,b=np.array(p1),np.array(p2);vec=b-a
        return self.part(name,parent,"cylinder",mat,(a+b)/2,(r,np.linalg.norm(vec),r),from_y(vec),sides)
    def anim(self,name,tracks):
        anim={"name":name,"samplers":[],"channels":[]}
        for node,path,times,values in tracks:
            samp={"input":self.accessor(times,"SCALAR"),"output":self.accessor(values,"VEC4" if path=="rotation" else "VEC3"),"interpolation":"LINEAR"}
            anim["channels"].append({"sampler":len(anim["samplers"]),"target":{"node":node,"path":path}})
            anim["samplers"].append(samp)
        self.g.setdefault("animations",[]).append(anim)
    def save(self,path):
        path.parent.mkdir(parents=True,exist_ok=True)
        from urllib.parse import quote
        for img in self.g.get("images",[]):
            if 'uri' in img:
                texname=img['name'].split(' ',1)
                source=TEXDIR/(texname[0]+"-"+texname[1]+(".jpg" if texname[1]=="basecolor" else ".png"))
                img['uri']=quote(os.path.relpath(source,path.parent).replace(os.sep,'/'),safe='/')
        self.g['buffers']=[{'byteLength':len(self.buf)}]
        js=json.dumps(self.g,separators=(',',':'),ensure_ascii=False).encode()
        js+=b' ' * (-len(js)%4)
        data=bytes(self.buf)+b'\0'*(-len(self.buf)%4)
        total=len(js)+len(data)+28
        path.write_bytes(struct.pack('<4sII',b'glTF',2,total)+struct.pack('<I4s',len(js),b'JSON')+js+
                         struct.pack('<I4s',len(data),b'BIN\0')+data)


def kart(s, i, parent=None, animated=True):
    name=NAMES[i]; col=PAINTS[i]; fur=FURS[i]
    chassis=s.node(name+" kart",parent,extras={"length":1.,"width":.65,"forward":"+Z","species":SPECIES[i]})
    def part(label,shape,mat,pos,scale,q=None,sides=16,at=chassis):
        return s.part(label,at,shape,mat,pos,scale,q,sides)
    part("Frame","box","metal:#474b44",(0,.19,-.025),(.36,.075,.79))
    turns=[]
    for z in (-.3,.315):
        s.bar("Axle",chassis,"metal:#87867a",(-.27,.145,z),(.27,.145,z),.024)
        for sign in (-1,1):
            pivot=s.node("Steer pivot" if z>0 else "Rear hub",chassis,(sign*.263,.145,z))
            if z>0:turns.append(pivot)
            tire=part("Rubber wheel","wheel","rubber",(0,0,0),(.145,.105,.145),rot((0,0,1),-math.pi/2),20,pivot)
            for side in (-1,1):
                part("Bottle-cap hub" if i==0 else "Axle plate","cylinder",col,(sign*side*.057,0,0),(.095,.014,.095),rot((0,0,1),-math.pi/2),14,pivot)
            part("Hub nut","cylinder","metal:#bdab86",(sign*.071,0,0),(.035,.016,.035),rot((0,0,1),-math.pi/2),6,pivot)
    hull=part("Main shell","sphere",col,(0,.245,0),(.213,.112,.405))
    part("Seat cushion","sphere","#40322a",(0,.327,-.095),(.124,.05,.143))
    part("Seat back","sphere","leather",(0,.369,-.189),(.133,.094,.035),rot((1,0,0),-.13))
    for sign in (-1,1):
        s.bar("Chassis runner",chassis,"metal:#b7a580",(sign*.17,.182,-.39),(sign*.19,.176,.39),.021)
        s.bar("Cockpit rim",chassis,col,(sign*.17,.273,-.22),(sign*.16,.31,.11),.024)
    if i in (0,7):
        # Thread spool shoulders, copper wound thread and bottle-cap nose.
        for z in (-.328,.10):
            part("Spool flange","cylinder","oak",(0,.24,z),(.212,.037,.152),rot((1,0,0),math.pi/2),20)
        for k in range(14):
            z=-.306+k*.029
            part("Thread winding","cylinder",("#be4e21" if k%2 else col),(0,.23,z),(.193,.016,.133),rot((1,0,0),math.pi/2))
    elif i in (1,6):
        part("Riveted tin lid","box",col,(0,.244,.045),(.417,.132,.64))
        part("Cork crash bumper","cylinder","oak",(0,.225,.426),(.069,.38,.072),rot((0,0,1),math.pi/2))
        for sign in (-1,1):
            for z in (-.22,-.1,.02,.14,.265):
                part("Tin rivet","sphere","metal:#d4b99b",(sign*.207,.255,z),(.012,.013,.013),sides=8)
    elif i in (2,5):
        for sign in (-1,1):
            s.bar("Reed chassis",chassis,"oak",(sign*.21,.251,-.36),(sign*.20,.24,.379),.035)
            for z in (-.30,.315):
                for k in range(5):
                    part("Suspension coil","cylinder","metal:#d1bc9b",(sign*.217,.181+k*.014,z),(.034,.01,.034))
    else:
        part("Seedpod shell","sphere","oak",(0,.253,.06),(.206,.147,.347))
        for sign in (-1,1):
            s.bar("Seedpod seam",chassis,col,(sign*.15,.306,-.18),(sign*.084,.341,.315),.016)
        s.bar("Wide wooden axle",chassis,"oak",(-.316,.15,-.305),(.316,.15,-.305),.042)
    for sign in (-1,1):
        part("Lamp bezel","cylinder","metal:#a7a190",(sign*.145,.273,.335),(.043,.033,.043),rot((1,0,0),math.pi/2))
        part("Glass headlight","sphere","#ffe4a2",(sign*.145,.273,.357),(.035,.035,.018))
    from detail_models import enrich
    return enrich(s,i,chassis,turns,animated)


def baked_groups(scene,atlas=None,lod=False):
    """Bake transforms while preserving smooth per-vertex normals, then weld vertices."""
    from vehicle_rig import tail_weights,transform
    def read(idx):
        a=scene.g["accessors"][idx];v=scene.g["bufferViews"][a["bufferView"]]
        dtype={5126:"<f4",5123:"<u2",5125:"<u4"}[a["componentType"]]
        return np.frombuffer(scene.buf,dtype=dtype,count=v["byteLength"]//np.dtype(dtype).itemsize,
                             offset=v["byteOffset"]).reshape(a["count"],-1)
    result={}
    def walk(n,world,bone=0,tail=False):
        node=scene.g["nodes"][n]
        if lod and any(token in node["name"].lower() for token in ("catchlight","whisker","ignition","bolt","stitch","harness buckle","zipper teeth","zipper pull","spark plug","striation","goggle glass highlight","tire bead","hub lug","crimp","fur layers","marginal hair")):
            return
        m=world@transform(node);extra=node.get("extras",{})
        bone=extra.get("rigBone",bone);tail=extra.get("tailDeform",tail)
        if 'mesh' in node:
            p=scene.g['meshes'][node['mesh']]['primitives'][0]
            mat=scene.g['materials'][p['material']]['name']
            g=result.setdefault(mat,{'p':[],'n':[],'uv':[],'i':[],'bone':[],'weight':[],'count':0})
            pts=read(p['attributes']['POSITION'])@m[:3,:3].T+m[:3,3]
            if tail:ids,weights,_=tail_weights(pts,scene.tail_path)
            else:ids,weights=np.full(len(pts),bone),np.ones(len(pts))
            g['bone'].append(ids);g['weight'].append(weights)
            nn=read(p['attributes']['NORMAL'])@np.linalg.inv(m[:3,:3])
            norm=np.linalg.norm(nn,axis=1);norm[norm<1e-6]=1.
            nn/=norm[:,None]
            tex=read(p['attributes']['TEXCOORD_0']).astype(float)
            if atlas:
                uvx,uvy,uw,uh=atlas[mat];tex=np.clip(tex,0,1)*[uw,uh]+[uvx,uvy]
            g['p'].append(pts*2);g['n'].append(nn);g['uv'].append(tex);g['i'].append(read(p['indices']).ravel().astype(np.int32)+g['count']);g['count']+=len(pts)
        for c in node.get("children",[]):walk(c,m,bone,tail)
    for root in scene.g["scenes"][0]["nodes"]:walk(root,np.eye(4))
    baked=[]
    for mat,g in result.items():
        verts=np.concatenate(g['p']);normals=np.concatenate(g['n']);idx=np.concatenate(g['i'])
        uv=np.concatenate(g["uv"]);bone=np.concatenate(g["bone"]);blend=np.concatenate(g["weight"])
        comp=np.c_[bone,np.rint(verts*8192),np.rint(normals*127),np.rint(uv*65535),np.rint(blend*255)].astype(np.int32)
        if lod:
            # Vertex clustering preserves species silhouettes & paint with a lower draw cost at distance.
            cells=np.c_[bone,np.rint(verts/.048)].astype(np.int32)
            _,reverse=np.unique(cells,axis=0,return_inverse=True)
            weight=np.bincount(reverse)
            unique=np.stack([np.rint(np.bincount(reverse,weights=col)/weight) for col in comp.T],axis=-1).astype(np.int32)
        else:unique,reverse=np.unique(comp,axis=0,return_inverse=True)
        idx=reverse[idx].reshape(-1,3)
        actual=unique[idx,1:4].astype(float)
        keep=np.linalg.norm(np.cross(actual[:,1]-actual[:,0],actual[:,2]-actual[:,0]),axis=1)>1.
        idx=idx[keep].ravel()
        encode=lambda a:base64.b64encode(a.tobytes()).decode("ascii")
        assert len(unique)<65535,f"16-bit index overflow in {mat}"
        ids,count=np.unique(unique[:,0],return_counts=True)
        runs=[int(v) for pair in zip(ids,count) for v in pair]
        flex=unique[np.isin(unique[:,0],(9,14,15)),9].astype('u1')
        baked.append({"name":mat,"color":list(rgb(palette.get(mat,mat.split(':')[-1]))),
                      "p":encode(unique[:,1:4].astype('<i2')),"n":encode(unique[:,4:7].astype('i1')),
                      "u":encode(unique[:,7:9].astype('<u2')),"i":encode(idx.astype('<u2')),"r":runs,"f":encode(flex)})
    return baked


def atlases(scenes,dest):
    keys=sorted(set(mat['name'] for s in scenes for mat in s.g['materials']))
    textured=[k for k in keys if k in palette];solid=[k for k in keys if k not in palette]
    # 256-pixel tiles for photographed materials. Tiny solid swatches share one tile.
    side=2048;cell=256;cols=side//cell
    height=2048 if len(textured)+1<=cols*8 else 4096
    assert len(textured)+1<=cols*(height//cell),(len(textured),len(solid))
    albedo=Image.new('RGB',(side,height));surface=Image.new('RGB',(side,height),(128,128,190));rect={}
    def fill(k,x,y,w,im,normal,rough):
        inner=w-4
        for atlas,texture in ((albedo,im),(surface,Image.merge('RGB',(*normal.split()[:2],rough)))):
            tiny=texture.resize((inner,inner),Image.Resampling.LANCZOS)
            v=np.pad(np.array(tiny),((2,2),(2,2),(0,0)),mode='edge')
            atlas.paste(Image.fromarray(v),(x,y))
        rect[k]=((x+2.5)/side,(y+2.5)/height,(inner-1)/side,(inner-1)/height)
    for j,k in enumerate(textured):
        im=Image.open(io.BytesIO(TEXTURES[k,'basecolor']));normal=Image.open(io.BytesIO(TEXTURES[k,'normal']))
        rough=Image.open(io.BytesIO(TEXTURES[k,'occlusion-roughness-metallic'])).getchannel('G')
        fill(k,(j%cols)*cell,(j//cols)*cell,cell,im,normal,rough)
    ox=len(textured)%cols*cell;oy=len(textured)//cols*cell
    for j,k in enumerate(solid):
        col=tuple(round(255*v) for v in rgb(k.split(':')[-1]))
        fill(k,ox+(j%16)*16,oy+(j//16)*16,16,Image.new('RGB',(12,12),col),Image.new('RGB',(12,12),(128,128,255)),Image.new('L',(12,12),88 if k.startswith('metal:') else 172))
    dest.mkdir(parents=True,exist_ok=True)
    albedo.save(dest/'kart-atlas.webp',quality=93,method=6)
    surface.save(dest/'kart-surface.webp',quality=90,method=6)
    return rect


def export_runtime(scenes,path):
    atlas=atlases(scenes,path.parent/'art')
    def rear_frame(groups,pivots):
        cam=np.array((.01,.37,-1));cam/=np.linalg.norm(cam)
        right=np.cross((0,1,0),cam);right/=np.linalg.norm(right);up=np.cross(cam,right);target=np.array((0,.91,-.04))
        def project(points):return np.c_[400+(points-target)@right*316.8,400-(points-target)@up*316.8]
        positions=np.concatenate([np.frombuffer(base64.b64decode(g['p']),dtype='<i2').reshape((-1,3))/8192 for g in groups])
        points=project(positions)
        left,top=np.maximum(0,np.floor(points.min(axis=0))).astype(int);r,b=np.minimum(800,np.ceil(points.max(axis=0))).astype(int)
        factor=min(472/(r-left),490/(b-top),1);w,h=round((r-left)*factor),round((b-top)*factor)
        offset=np.array(((512-w)//2,505-h));scale=np.array((w/(r-left),h/(b-top)))
        anchors=((project(np.array(pivots))-[left,top])*scale+offset)/512.
        camera={"right":right.tolist(),"up":up.tolist(),"forward":cam.tolist(),"pixelsPerUnit":(316.8*scale).tolist(),
                "bounds":list(map(int,(left,top,r,b))),"size":[w,h],"offset":offset.tolist()}
        return anchors.round(7).tolist(),camera
    raw=[]
    for i,s in enumerate(scenes):
        high=baked_groups(s,atlas);rear_pivots,rear_camera=rear_frame(high,s.rig_data["pivots"])
        raw.append({'name':NAMES[i],'groups':high,'lod':baked_groups(s,atlas,True),'rig':s.rig_data,
                    'rearPivots':rear_pivots,'rearCamera':rear_camera})
    decode="""(function(models){
  function buffer(encoded) {
    const bytes = Uint8Array.from(atob(encoded), c => c.charCodeAt(0));
    return bytes.buffer;
  }
  function group(g){
    const positions=Float32Array.from(new Int16Array(buffer(g.p)), v=>v/8192);
    const rig=new Uint8Array(positions.length/3), flex=new Float32Array(rig.length).fill(1);
    const weights=new Uint8Array(buffer(g.f));
    for(let j=0,start=0,f=0;j<g.r.length;j+=2){
      const id=g.r[j],end=start+g.r[j+1];rig.fill(id,start,end);
      if(id===9||id===14||id===15)for(let k=start;k<end;k++)flex[k]=weights[f++]/255;
      start=end;
    }
    return {
    name: g.name, color:g.color,
    positions,rig,parts:rig,flex,
    normals:Float32Array.from(new Int8Array(buffer(g.n)), v=>v/127),
    uvs:Float32Array.from(new Uint16Array(buffer(g.u)), v=>v/65535),
    indices:new Uint16Array(buffer(g.i))
  };}
  window.AcornKartModels = models.map(model => ({name:model.name,groups:model.groups.map(group),lod:model.lod.map(group),
    rig:model.rig,pivots:model.rig.pivots,rearPivots:model.rearPivots,rearCamera:model.rearCamera}));
})("""
    text=decode+json.dumps(raw,separators=(',',':'))+');\n'
    for key,filename in (("Texture","kart-atlas.webp"),("Surface","kart-surface.webp")):
        embedded=base64.b64encode((path.parent/'art'/filename).read_bytes()).decode('ascii')
        text+=f'window.AcornKart{key}=(typeof location!=="undefined" && location.protocol==="file:")?"data:image/webp;base64,{embedded}":"art/{filename}";\n'
    staged=path.with_name(path.name+'.tmp')
    staged.write_text(text,encoding='utf-8')
    staged.replace(path)


COURSES=[
    ("Hoh Root Run","soil","bark",840,"Hollow nurse log"),
    ("Bamboo Bell Run","stone","plank",900,"Bell bridge"),
    ("Sluice Sprint","brick","plank",930,"Pumping windmill"),
    ("Finbreak Canyon","sand","stone",1000,"Sandstone arch"),
    ("Mirror Saltway","salt","salt",1020,"Salt island"),
    ("Chimney Spiral","sand","stone",1100,"Capped tuff pinnacles"),
    ("Cloudfall Canopy","plank","stone",1030,"Waterfall gallery"),
    ("Basalt Breakwater","basalt","sand",1100,"Basalt gate")
]
LOCATIONS=["Olympic Peninsula, Washington","Saga–Arashiyama, Kyoto","Kinderdijk, Netherlands",
           "Moab, Utah","Salar de Uyuni, Bolivia","Cappadocia, Türkiye","El Yunque, Puerto Rico","Vík, Iceland"]
SURFACES={"soil":{"grip":.94,"roll":.019},"stone":{"grip":1.05,"roll":.014},"bark":{"grip":.87,"roll":.022},
          "plank":{"grip":.82,"roll":.015},"sand":{"grip":.7,"roll":.040},"salt":{"grip":1.00,"roll":.014},
          "brick":{"grip":.97,"roll":.018},"basalt":{"grip":.89,"roll":.025}}


def acorn(s,parent,animated=False):
    base=s.node("Acorn pickup",parent,extras={"trigger":{"shape":"sphere","radius":.7},"respawnSeconds":2.,"emptyInventoryOnly":True})
    body=s.node("Bobbing shell",base)
    s.part("Faceted nut",body,"acorn","#db8738",(0,.67,0),(.45,.62,.45),sides=12)
    s.part("Textured cupule",body,"cap","bark",(0,.82,0),(.465,.44,.465),sides=16)
    s.part("Golden rim",body,"cylinder","metal:#e3aa50",(0,.765,0),(.321,.038,.321),sides=16)
    s.bar("Stem",body,"oak",(0,.955,0),(.047,1.113,0),.041)
    for j in range(14):
        a=j*TAU/14;r=.30
        s.part("Cap scale",body,"rock","oak",(r*math.cos(a),.84,r*math.sin(a)),(.049,.074,.049),rot((0,1,0),a),6)
    if animated:
        s.anim("Hover",[(body,"translation",[0,.58,1.16],[[0,0,0],[0,.09,0],[0,0,0]])])
    return base


def finish(s,p,width=5.35):
    root=s.node("Finish gantry",p)
    for x in (-width/2,width/2):
        s.bar("Bark post",root,"bark",(x,0,0),(x+.10,2.8,0),.122)
        for y in (.22,2.23,2.5):
            s.part("Wound twine",root,"cylinder","weave",(x+.10*y/2.8,y,0),(.137,.063,.137))
    s.bar("Crossbeam",root,"oak",(-width*.53,2.54,0),(width*.53,2.54,0),.085)
    for i in range(12):
        x=(i+.5)*width/12-width/2
        for row in range(2):
            s.part("Checkered cloth",root,"box",["#eadbc1","#333934"][(i+row)%2],(x,2.42-row*.16+.13*(2*x/width)**2,0),
                   (width/12,.16,.026))
    return root


def tree(s,p,variant=0):
    root=s.node("Maple" if variant==0 else "Fern",p)
    if variant==0:
        s.part("Tree trunk",root,"cylinder","bark",(0,3.5,0),(.74,7,.71),rot((0,0,1),.04),10)
        for j in range(7):
            a=.2+j*TAU/7
            x,z=math.cos(a),math.sin(a)
            s.bar("Root",root,"bark",(0,1.19,0),(x*1.7,.04,z*1.7),.22,8)
            s.bar("Limb",root,"bark",(0,4.3+.22*(j%3),0),(x*2.2,6.35+(j%3)*.51,z*2.2),.24,8)
            s.part("Leaf canopy",root,"sphere",["#416740","#527d47","#749653"][j%3],(x*1.84,6.62+(j%3)*.52,z*1.84),(1.82,1.1,1.6),sides=10)
    else:
        for j in range(7):
            a=j*TAU/7;X,Z=math.cos(a),math.sin(a)
            for k in range(1,5):
                t=k/4;x,z=X*t,Z*t;y=.13+math.sin(t*math.pi*.82)*.53
                s.bar("Frond",root,"grass",(X*(t-.25),y-.12,Z*(t-.25)),(x,y,z),.017,6)
                for sign in (-1,1):
                    s.bar("Pinna",root,"#64924e",(x,y,z),(x+.17*Z*sign,y+.06,z-.17*X*sign),.046*(1-.13*k),5)
    return root


def landmark(s,k,p,animated=False):
    root=s.node(COURSES[k][4],p)
    def part(label,shape,mat,pos,sc,q=None,sides=12):
        return s.part(label,root,shape,mat,pos,sc,q,sides)
    if k==0:
        # Independent bark wedges leave a traversable opening and an exposed end grain.
        for j in range(16):
            a=TAU*j/16; center=(1.66*math.cos(a),2.10+1.66*math.sin(a),0)
            part("Hollow bark stave","box","bark",center,(.55,.28,9.5),rot((0,0,1),a-math.pi/2))
        for z in (-4.77,4.77):
            for j in range(16):
                a=j*TAU/16;part("Split end grain","box","oak",(1.66*math.cos(a),2.10+1.66*math.sin(a),z),(.55,.28,.06),rot((0,0,1),a-math.pi/2))
        s.bar("Root plate left",root,"bark",(-1.5,2.3,-4.65),(-2.2,.2,-5.52),.30)
        s.bar("Root plate right",root,"bark",(1.5,2.3,-4.65),(2.55,.23,-4.9),.33)
        part("Mossy crown","box","grass",(0,3.85,0),(2.1,.16,9.5))
        for x in (-.98,.98):
            s.bar("Twig rail",root,"oak",(x,4.17,-4.75),(x,4.17,4.75),.056)
        s.node("Lower recovery",root,(0,.45,4.85),extras={"kind":"respawn","level":"lower"})
    elif k==1:
        part("Wet bridge deck","box","plank",(0,1.35,0),(5.1,.32,14))
        for x in (-2.47,2.47):
            s.bar("Bridge handrail",root,"oak",(x,2.6,-7),(x,2.6,7),.103)
            for z in range(-7,8,2):
                s.bar("Rail post",root,"bark",(x,.08,z),(x,2.65,z),.095)
                if z<6:s.bar("Truss web",root,"oak",(x,.25,z),(x,1.35,z+2),.11)
        for x in (-.82,.82):
            s.bar("Bell rope",root,"weave",(x,4.2,6.3),(x,3.75,6.3),.037)
            part("Bronze gate bell","cone","metal:#bb9857",(x,3.58,6.3),(.28,.41,.28))
        s.bar("Bell transom",root,"bark",(-3.1,4.23,6.3),(3.1,4.23,6.3),.105)
        for x in (-2.64,2.64):s.bar("Bell gate",root,"oak",(x,0,6.3),(x,4.3,6.3),.12)
    elif k==2:
        part("Windmill base","cone","brick",(0,3.65,0),(3.10,11.3,3.10))
        part("Thatched cap","cone","oak",(0,7.72,0),(1.91,2.15,1.91))
        for y in (1.2,3.0,5.0):part("Mill window","box","#48403b",(0,y,2.7*(1-y/9.4)),(.61,.89,.09))
        hub=s.node("Sail axle",root,(0,6.16,1.38),q=rot((0,0,1),.28))
        for j in range(4):
            vane=s.node("Sail assembly",hub,q=rot((0,0,1),j*math.pi/2))
            s.bar("Sail spar",vane,"oak",(0,0,0),(0,4.52,0),.079)
            s.part("Sailcloth",vane,"box","#dcba89",(.37,2.86,0),(.68,3.02,.04))
            for y in np.linspace(1.4,4.4,8):s.bar("Lattice",vane,"bark",(0,y,.041),(.73,y,.041),.032)
        if animated:s.anim("Mill sails",[(hub,"rotation",[0,3,6,9,12],[rot((0,0,1),.28+j*math.pi/2) for j in range(5)])])
    elif k in (3,7):
        for side in (-1,1):
            for j in range(6):
                height=[6.4,6.1,5.6,4.6,3.1,2.3][j]
                part("Weathered fin" if k==3 else "Basalt prism","rock" if k==3 else "cylinder","sand" if k==3 else "basalt",
                     (side*(3.35+j*.64),height*.49,(j%3)*.3),(1.03,height,1.15),rot((0,1,0),j*.17),7 if k==3 else 6)
        for j in range(8):
            a=j*math.pi/7
            part("Arch crown","rock","sand" if k==3 else "basalt",(3.5*math.cos(a),5.4+1.15*math.sin(a),0),(.91,1.4,.99),rot((0,0,1),.22*math.cos(a)),7)
    elif k==4:
        for j in range(11):
            a=j*2.4;r=math.sqrt(j);h=3.05-r*.55
            part("Volcanic outcrop","rock","basalt",(math.cos(a)*r,h/2,math.sin(a)*r),(1.63,h,1.38),rot((0,1,0),a),8)
        for side in (-1,1):
            s.bar("Rally flagpole",root,"oak",(4*side,0,1.47),(4*side,2.46,1.47),.045)
            part("Wind marker","box","#de6e36",(4*side+.35,2.25,1.48),(.70,.36,.033))
    elif k==5:
        for j,(x,z,h) in enumerate(((-2.75,.8,6.8),(0,-1.1,9.8),(2.6,1.3,5.2))):
            part("Tuff shaft","cone","sand",(x,h*.59,z),(1.53,h*1.27,1.68),sides=9)
            part("Erosion cap","rock","#946b60",(x,h*.93,z),(1.21,1.60,1.35),rot((0,1,0),j*.55),8)
    elif k==6:
        for j in range(9):
            x=(j-4)*1.05;h=6.7+math.cos(j*.96)*.77
            part("Gallery cliff","rock","stone",(x,.5*h,-1.21+.13*(j%3)),(1.27,h,1.2),sides=8)
        for j in range(9):
            x=-1.43+j*.36;h=6.82-.13*abs(j-4)
            part("Falling water","box",["#99d9d0","#b8ece3","#88c8c3"][j%3],(x,h/2,.28+.06*(j%3)),(.41,h,.10))
            part("Foam","sphere","#c6e8dd",(x,.15,.37+.11*(j%3)),(.39,.24,.43))
        part("Plunge pool","sphere","#539d99",(0,.06,.89),(3.5,.12,2.3))
    return root


def scenery(s,k,p):
    if k==0:return tree(s,p)
    root=s.node(["","Bamboo stand","Sluice chamber","Layered sandstone fin","Salt crust markers","Workshop entrance","Tree fern","Coastal basalt"][k],p)
    def add(label,shape,mat,pos,sc,q=None,sides=10):
        return s.part(label,root,shape,mat,pos,sc,q,sides)
    if k==1:
        for j in range(6):
            a=j*2.39;x=math.cos(a)*1.2;z=math.sin(a)*1.2;h=4.6+.42*(j%4)
            add("Bamboo culm","cylinder","#79904e",(x,h/2,z),(.1,h,.1))
            for v in np.arange(.56,h-.1,.64):
                add("Node ring","cylinder","#a1aa65",(x,v,z),(.115,.055,.115))
            for l in range(3):
                angle=a+l*2;X,Z=math.cos(angle),math.sin(angle)
                s.bar("Leaf branch",root,"#698649",(x,h*.65,z),(x+X,h*.84,z+Z),.04)
                add("Leaf canopy","sphere","#577642",(x+X,h*.85,z+Z),(.67,.17,.55),sides=8)
    elif k==2:
        for x in (-1.36,1.36):
            add("Brick wall","box","brick",(x,1.46,0),(.42,2.92,2.75))
        add("Gate teeth","box","metal:#6f7267",(0,1.3,0),(2.53,1.75,.23))
        s.bar("Pulley axle",root,"oak",(-1.65,2.85,0),(1.65,2.85,0),.16)
    elif k in (3,5,7):
        mat="sand" if k!=7 else "basalt"
        for j in range(5):
            height=(4.2-.62*j) if k!=5 else 3.2+.24*(j%2)
            add("Stone ridge","rock" if k!=7 else "cylinder",mat,(j*.66,height/2,.23*(j%2)),(.78,height,1.11),rot((0,1,0),j*.1),6)
        if k==5:
            for x in (-.85,.85):s.bar("Support post",root,"oak",(x,0,1.47),(x,2.38,1.47),.14)
            s.bar("Workshop beam",root,"bark",(-1.14,2.37,1.47),(1.14,2.37,1.47),.16)
    elif k==4:
        add("Salt block","rock","salt",(0,.47,0),(1.46,.92,.74))
        s.bar("Marker pole",root,"oak",(0,.62,0),(0,2.38,0),.045)
        add("Salmon pennant","box","#db6744",(.24,2.12,0),(.52,.35,.036))
    elif k==6:
        s.bar("Fern trunk",root,"bark",(0,0,0),(.13,3.62,.11),.26)
        for j in range(10):
            a=TAU*j/10;x,z=math.cos(a),math.sin(a)
            s.bar("Frond rib",root,"#49804d",(0,3.55,0),(1.6*x,3.91,1.6*z),.07)
            for n in range(1,6):
                t=n*.29;w=.34*(1-.105*n)
                for side in (-1,1):
                    s.bar("Leaflet",root,"#5d9654",(t*x,3.56+t*.21,t*z),(t*x+w*z*side,3.54+t*.21,t*z-w*x*side),.079,6)
    return root


def road_mesh(points,closed=False,banked=False):
    """Ribbon with an independent continuous collision surface and tiled distance UVs."""
    pts=points+([points[0]] if closed else [])
    pos,norm,uv,inds=[],[],[],[]
    dist=0.
    for j,p in enumerate(pts):
        i=j%len(points);prev=points[(i-1)%len(points)] if (closed or i) else points[0]
        nxt=points[(i+1)%len(points)] if (closed or i<len(points)-1) else points[-1]
        t=np.asarray(nxt[:3])-np.asarray(prev[:3]);t/=max(1e-9,np.linalg.norm(t))
        right=np.array([t[2],0,-t[0]]);right/=max(1e-9,np.linalg.norm(right))
        tilt=.04*math.sin(TAU*i/len(points)*3) if banked else 0.
        right[1]=tilt
        normal=np.cross(t,right);normal/=max(np.linalg.norm(normal),1e-9)
        if j:dist+=np.linalg.norm(np.array(p[:3])-np.array(pts[j-1][:3]))
        for side in (-1,1):
            pos.append((np.array(p[:3])+right*p[3]*side).tolist());norm.append(normal.tolist())
            uv.append([(side+1)*p[3]/2,dist/3])
        if j:
            d=2*j; inds.extend([d-2,d,d-1,d-1,d,d+1])
    return pos,norm,uv,inds


def modular(s,kind,p=None):
    root=s.node(kind,p,extras={"unit":"kart length","up":"+Y","forward":"+Z"})
    points=[]
    if kind in ("Straight","Bend","Ramp","Banked curve"):
        for j in range(17):
            t=j/16
            if kind in ("Bend","Banked curve"):
                a=t*math.pi/3;point=[9.0*(1-math.cos(a)),0,9.0*math.sin(a),2.]
            else:point=[0.,1.8*t if kind=="Ramp" else 0.,9*t,2.]
            points.append(point)
        mesh=s.mesh(kind,"soil",geo=road_mesh(points,banked=kind=="Banked curve"))
        s.node("Drive and collision surface",root,mesh=mesh,extras={"collision":"trimesh","surface":"soil"})
        s.node("Entry snap",root,points[0][:3]);s.node("Exit snap",root,points[-1][:3])
    elif kind=="Timber deck":
        for j in range(15):s.part("Board",root,"box","plank",(0,0,j*.4),(4.2,.14,.385))
        for x in (-1.55,1.55):s.bar("Joist",root,"oak",(x,-.18,-.2),(x,-.18,5.8),.11)
        s.node("Drive collider",root,(0,.073,2.8),extras={"collision":{"shape":"box","halfExtents":[2.1,.06,3.]}})
        s.node("Entry snap",root,(0,.07,-.2));s.node("Exit snap",root,(0,.07,5.8))
    elif kind=="Twig rail":
        for z in (0,2,4):s.bar("Post",root,"bark",(0,0,z),(.03,.92,z),.065)
        for y in (.36,.75):s.bar("Rail",root,"oak",(0,y,-.06),(0,y,4.06),.046)
        s.node("Entry snap",root,(0,0,0));s.node("Exit snap",root,(0,0,4))
    elif kind=="Hazard chevron":
        s.bar("Sign post",root,"oak",(0,0,0),(0,1.7,0),.062)
        s.part("Signal board",root,"box","#dca94a",(0,1.3,0),(1.13,.66,.075))
        for x in (-.28,.14):
            for sign in (-1,1):
                s.part("Chevron",root,"box","#303b36",(x,1.3+.102*sign,.044),(.40,.105,.025),rot((0,0,1),sign*-.56))
    return root


def default_route(i):
    points=[]
    for j in range(320):
        a=TAU*j/320;r=1+.19*math.cos(3*a+.55*i)+.11*math.sin(4*a-.45*i)
        if i==0:
            x=math.sin(a);z=.64*math.sin(2*a+.18);h=1.3+2.7*math.exp(-((a-math.pi)/.40)**2)
        else:
            x=math.cos(a)*r;z=.70*math.sin(a)*r;h=(math.sin(2*a+.5*i)+1)*[0,2,1.2,3.4,.34,5,4.4,3.4][i]
        points.append([x,h,z,2.0])
    length=sum(math.hypot(p[0]-n[0],p[2]-n[2]) for p,n in zip(points,[*points[1:],points[0]]))
    scale=COURSES[i][3]/length
    for p in points:p[0]*=scale;p[2]*=scale
    return {"points":points,"branchA":.37,"branchB":.55}


def sampled_point(points,fraction,lateral=0):
    v=(fraction%1)*len(points);idx=int(v);t=v-idx
    p=points[idx];n=points[(idx+1)%len(points)]
    a=math.atan2(n[0]-p[0],n[2]-p[2])
    return [(1-t)*p[0]+t*n[0]+math.cos(a)*lateral,(1-t)*p[1]+t*n[1],(1-t)*p[2]+t*n[2]-math.sin(a)*lateral],a


def clone(s,node,parent,pos,q=None,scale=None):
    def add(n,dst,is_root=False):
        obj=s.g["nodes"][n];new=s.node(obj['name'],dst,pos if is_root else obj.get('translation'),
            scale if is_root else obj.get('scale'),q if is_root else obj.get('rotation'),obj.get("mesh"),copy.deepcopy(obj.get('extras')))
        for child in obj.get("children",[]):add(child,new)
        return new
    return add(node,parent,True)


def assembled(i,route,output):
    name,mainmat,altmat,length,feature=COURSES[i]
    s=Scene(name);points=route['points'];n=len(points)
    main=s.node(name,extras={"unit":"kart length","location":LOCATIONS[i],"length":length,"surfaceSettings":SURFACES})
    roadway=s.node("Roads, checkpoints and routes",main)
    road=s.mesh("Main ribbon",mainmat,geo=road_mesh(points,closed=True))
    s.node("Main drive surface",roadway,mesh=road,extras={"collision":"smooth trimesh","route":"main","surface":mainmat})
    branchA=route.get("branchA",.37);branchB=route.get("branchB",.55)
    alt=route.get('branchPoints')
    if not alt:
        alt=[]
        for j in range(43):
            t=j/42;f=branchA+(branchB-branchA)*t;p,_=sampled_point(points,f,math.sin(math.pi*t)*4.83)
            alt.append([*p,1.1])
    shape=s.mesh("Branch ribbon",altmat,geo=road_mesh(alt))
    s.node("Technical branch",roadway,mesh=shape,extras={"collision":"smooth trimesh","route":"branch","surface":altmat})
    def place(f,x=0):
        p,a=sampled_point(points,f,x)
        return p,rot((0,1,0),a)
    split=s.node("Split checkpoint graph",main)
    sections=sorted(set([0,.125,.25,.375,.50,.625,.75,.875,round(branchA,6),round(branchB,6)]))
    ids=[f"main-{j:02d}" for j in range(len(sections))]
    g=[]
    for j,f in enumerate(sections):
        p,q=place(f);next_id=[ids[(j+1)%len(sections)]]
        if abs(f-branchA)<.0001:next_id.append("branch-mid")
        extras={"id":ids[j],"next":next_id,"lapFraction":f,"kind":"height-aware checkpoint",
                "triggerHalfExtents":[points[int(n*f)%n][3]+.4,1.25,.5],"respawnForward":True}
        s.node(ids[j],split,p,q=q,extras=extras);g.append({**extras,"position":p,"rotation":q})
    p=alt[len(alt)//2][:3]
    target=ids[min(range(len(sections)),key=lambda j:abs(sections[j]-branchB))]
    altcp={"id":"branch-mid","next":[target],"lapFraction":(branchA+branchB)/2,"kind":"height-aware checkpoint",
           "triggerHalfExtents":[1.5,1.25,.45],"position":p}
    s.node("Branch checkpoint",split,p,extras=altcp);g.append(altcp)
    objects=s.node("Track furniture",main)
    p,q=place(0);gate=finish(s,objects,points[0][3]*2+.7)
    s.g['nodes'][gate].update(translation=p,rotation=q)
    for seat in range(8):
        grid=route.get('grid')
        p,q=place(*grid[seat]) if grid else place(-.005*int(seat/2)-.004,(.61 if seat%2 else -.61))
        s.node(f"Grid position {seat+1}",objects,p,q=q,extras={"seat":seat+1,"kind":"spawn"})
    # A single original pickup mesh is shared by all nine placed trigger objects.
    rows=route.get('pickups',[.18,.48,.80])
    pickupRoot=s.node("Acorn rows",objects)
    template=None
    for j,f in enumerate(rows):
        for lane in route.get('pickupLanes',[-1.42,0,1.42]):
            pos,q=place(f,lane)
            if template is None:
                template=acorn(s,pickupRoot);s.g['nodes'][template].update(translation=pos,rotation=q)
            else:clone(s,template,pickupRoot,pos,q)
    regional=s.node("Regional scenery",main)
    f=route.get('bridge',[.26,.34,.66,.38,.25,.29,.52,.67][i])
    w=points[int(n*f)][3]
    p,q=place(f,0. if i in (0,1,3,7) else w+[0,0,3.8,0,5.0,3.0,5.0,0][i])
    scale=[1.,1.,1.]
    if i==0:
        scale=[w/1.14,.47,1.5];p[1]-=3.95*scale[1]
    elif i==1:
        scale=[w/2.53,1.,1.];p[1]-=1.51
    hero=landmark(s,i,regional,animated=True);s.g["nodes"][hero].update(translation=p,rotation=q,scale=scale)
    rng=random.Random(1580+i)
    scenery_obj=None
    for j in range(32):
        f=(j+.4)/32;w=points[int(n*f)%n][3]
        p,q=place(f,(1 if j%2 else -1)*(w+rng.uniform(4.2,11.5)))
        scale=[rng.uniform(.75,1.32)]*3
        if scenery_obj is None:
            scenery_obj=scenery(s,i,regional);s.g['nodes'][scenery_obj].update(translation=p,rotation=q,scale=scale)
        else:clone(s,scenery_obj,regional,p,q,scale)
    for j in range(15):
        p,q=place(j/15+.013,points[int(n*j/15)][3]+.15)
        sign=modular(s,"Hazard chevron",objects);s.g["nodes"][sign].update(translation=p,rotation=q,scale=[.65]*3)
    p,a=sampled_point(points,.0);cam=s.node("Grid chase camera",main,[p[0]-math.sin(a)*3.5,p[1]+1.35,p[2]-math.cos(a)*3.5],q=rot((0,1,0),a+math.pi))
    s.g["cameras"]=[{"name":"Chase lens","type":"perspective","perspective":{"yfov":1.05,"znear":.03,"zfar":1600}}]
    s.g['nodes'][cam]['camera']=0
    # Ambient editor lighting with an explicit directional sun for engines supporting KHR_lights_punctual.
    s.g['extensionsUsed']=["KHR_lights_punctual"]
    s.g['extensions']={"KHR_lights_punctual":{"lights":[{"name":"Warm afternoon sun","type":"directional","color":[1,.90,.73],"intensity":2.4}]}}
    sun=s.node("Sun",main,q=rot((1,0,0),-1.05))
    s.g['nodes'][sun]['extensions']={"KHR_lights_punctual":{"light":0}}
    path=output/"Courses"/name
    s.save(path.with_suffix(".glb"))
    path.with_suffix(".json").write_text(json.dumps({"name":name,"location":LOCATIONS[i],"units":"kart lengths",
        "mainRoute":points,"branchRoute":alt,"checkpointGraph":g,"pickupRows":rows,"surfaces":SURFACES},
        indent=None,separators=(',',':')),encoding="utf-8")


def build(out, routefile=None):
    maps(out/"Materials")
    scenes=[]
    for i in range(len(NAMES)):
        s=Scene(NAMES[i]);kart(s,i);s.save(out/"Racers"/(NAMES[i]+".glb"));scenes.append(s)
    for kind in ("Straight","Bend","Ramp","Banked curve","Timber deck","Twig rail","Hazard chevron","Acorn pickup","Finish gate"):
        s=Scene(kind)
        if kind=="Acorn pickup":acorn(s,None,True)
        elif kind=="Finish gate":finish(s,None)
        else:modular(s,kind)
        s.save(out/"Prefabs"/"Track"/(kind+".glb"))
    routes=json.loads(routefile.read_text(encoding="utf-8")) if routefile and routefile.is_file() else [default_route(i) for i in range(8)]
    for i,course in enumerate(COURSES):
        for variant in (0,1):
            s=Scene(course[4] if not variant else course[0]+" scenery")
            node=scenery(s,i,None) if variant else landmark(s,i,None,True)
            s.save(out/"Prefabs"/"Regional"/f"{course[0]} - {s.g['nodes'][node]['name']}.glb")
        assembled(i,routes[i],out)
    return scenes


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output",type=Path)
    parser.add_argument("--routes",type=Path,default=Path(__file__).with_name("routes.json"))
    parser.add_argument("--runtime",type=Path,help="Also export compact JS racer meshes for the web game.")
    args=parser.parse_args()
    racers=build(args.output,args.routes)
    if args.runtime:export_runtime(racers,args.runtime)
