"""Hero-level, articulated kart and woodland racer geometry."""
import math
from functools import lru_cache

import numpy as np
from build_models import FURS, NAMES, PAINTS, TAU, rot
EAR_LENGTH=[.175,.126,.267,.151,.072,.203,.087,.047]
EAR_WIDTH=[.089,.065,.054,.055,.039,.090,.048,.026]


@lru_cache(maxsize=64)
def torus(major=1.,tube=.10,sides=32,segments=8):
    # In the XY plane, normal points toward positive Z.
    p,n,uv,idx=[],[],[],[]
    for j in range(segments+1):
        a=j*TAU/segments
        for k in range(sides+1):
            b=k*TAU/sides;c=math.cos(b);s=math.sin(b)
            p.append(((major+tube*math.cos(a))*c,(major+tube*math.cos(a))*s,tube*math.sin(a)))
            n.append((math.cos(a)*c,math.cos(a)*s,math.sin(a)));uv.append((k/sides,j/segments))
            if j and k:
                d=j*(sides+1)+k;a0=d-sides-2
                idx.extend((a0,a0+1,d-1,a0+1,d,d-1))
    return p,n,uv,idx


@lru_cache(maxsize=8)
def plate():
    p=[];n=[];uv=[];idx=[]
    for y in range(3):
        for x in range(11):
            X=x/5-1;Y=y-1
            p.append((X,Y,-.09*X*X));n.append((.18*X,0,1));uv.append((x/10,1-y/2))
            if x and y:
                q=y*11+x;idx.extend((q-12,q-11,q-1,q-11,q,q-1))
    return p,n,uv,idx


@lru_cache(maxsize=8)
def head_shape(i):
    # A continuous shaped cranium with a broader brow, tapered muzzle and jaw.
    p,n,uv,idx=[],[],[],[]
    nx,ny=52,32
    def point(a,b):
        elevation=math.sin(b);r=math.cos(b);s=math.sin(a);c=math.cos(a)
        front=max(0,c);lower=max(0,-elevation)
        width=[.160,.152,.158,.155,.157,.159,.175,.148][i]*(1+.10*math.exp(-((elevation+.18)/.26)**2)-lower*.19)
        z=.127*r*c+[.034,.049,.029,.035,.045,.068,.058,.068][i]*(front**3)*math.exp(-((elevation+.21)/.40)**2)
        return np.array([r*s*width,elevation*[.155,.151,.158,.145,.146,.148,.137,.135][i],z])
    for y in range(ny+1):
        b=(y/ny-.5)*math.pi
        for x in range(nx+1):
            a=(x/nx-.5)*TAU;pt=point(a,b)
            norm=np.cross(point(a+.0001,b)-point(a-.0001,b),point(a,min(math.pi*.5,b+.0001))-point(a,max(-math.pi*.5,b-.0001)))
            length=np.linalg.norm(norm)
            norm=norm/length if length>1e-10 else np.array([0,(-1 if y==0 else 1),0])
            p.append(pt.tolist());n.append(norm.tolist());uv.append((x/nx,1-y/ny))
            if y and x:
                q=y*(nx+1)+x;v=q-nx-2;idx.extend((v,v+1,q-1,v+1,q,q-1))
    return p,n,uv,idx


@lru_cache(maxsize=8)
def ear_shape(i,inside=False):
    # Concentric sculpted dishes: pinched at the base, thick rim, shallow pinna.
    p,n,uv,idx=[],[],[],[]
    radial,around=11,40
    length=EAR_LENGTH[i];width=EAR_WIDTH[i]
    def pt(a,r):
        cy=math.sin(a);cx=math.cos(a);t=(r*cy+1)/2
        widthscale=1-(.24*(abs(cy)**2) if i==2 else .14*max(-cy,0))
        if i==3:widthscale*=1-.6*max(cy,0)**2
        if i==5:widthscale*=max(.18,1.21-1.12*t)
        card=[width*r*cx*widthscale,length*(.5+.5*r*cy),.006+.026*math.exp(-((r-.87)/.23)**2)-.008*(1-r)]
        if inside:card[2]+=.001
        return np.array(card)
    for j in range(radial+1):
        R=j/radial*(.84 if inside else 1.)
        if j==0:R=.0001
        for k in range(around+1):
            a=k*TAU/around;v=pt(a,R)
            if inside:
                v[0]*=.89;v[1]=v[1]*.90+length*.055
                v[2]+=.008
            norm=np.cross(pt(a,min(1.,R+.001))-pt(a,max(0,R-.001)),pt(a+.001,R)-pt(a-.001,R))
            norm/=max(1e-9,np.linalg.norm(norm))
            p.append(v.tolist());n.append(norm.tolist());uv.append((.5+.49*R*math.cos(a),.5-.49*R*math.sin(a)))
            if j and k:
                d=j*(around+1)+k;o=d-around-2;idx.extend((o,d-1,o+1,o+1,d-1,d))
    return p,n,uv,idx


@lru_cache(maxsize=4)
def tuft_mesh():
    p,n,uv,idx=[],[],[],[]
    for j in range(7):
        t=j/6;r=(1-t)**.6*(.7+.3*math.sin(math.pi*t))
        for x in range(9):
            a=x*TAU/8
            p.append((r*math.cos(a),t,r*math.sin(a)*.51+t*t*.42))
            nn=np.array([math.cos(a),.45,math.sin(a)*1.8]);nn/=np.linalg.norm(nn);n.append(nn.tolist());uv.append((x/8,t))
            if j and x:
                d=j*9+x;o=d-10;idx.extend((o,d-1,o+1,o+1,d-1,d))
    return p,n,uv,idx


def enrich(s,i,chassis,turns,animated):
    col,fur,cream=PAINTS[i],FURS[i],"lightfur%d"%i
    X=(1,0,0);Y=(0,1,0);Z=(0,0,1)
    def obj(at,name,shape,mat,pos,scale,q=None,sides=24):
        return s.part(name,at,shape,mat,pos,scale,q,sides)
    def custom(at,name,key,geometry,mat,pos,scale=(1,1,1),q=None):
        return s.node(name,at,pos,scale,q,s.mesh(key,mat,geo=geometry))
    def ring(at,name,mat,pos,scale,q=None,tube=.08):
        return custom(at,name,"torus %.3f"%tube,torus(tube=tube),mat,pos,scale,q)
    def rods(at,name,mat,points,radius,sides=10):
        for a,b in zip(points,points[1:]):s.bar(name,at,mat,a,b,radius,sides)
    def tuft(at,name,mat,pos,scale,q=None):
        return custom(at,name,"Tapered curved tuft",tuft_mesh(),mat,pos,scale,q)
    def decal(at,name,mat,pos,scale,q=None):
        return custom(at,name,"Curved decal plate",plate(),mat,pos,scale,q)
    def ell(at,name,mat,pos,scale,q=None,segments=26):
        return obj(at,name,"sphere",mat,pos,scale,q,segments)

    # Pressed hubs, lugs, tire bead and directional tread share the steering pivot.
    wheel_roots=[n for n in s.g["nodes"][chassis]["children"] if s.g["nodes"][n]["name"] in ("Steer pivot","Rear hub")]
    for w in wheel_roots:
        x=s.g["nodes"][w]["translation"][0];side=1 if x>0 else -1
        orient=rot(Y,side*math.pi/2)
        for radius in (.109,.119,.081):
            ring(w,"Embossed tire bead","rubberwall",(side*.054,0,0),(radius,radius,.052),orient,.032)
        ring(w,"Pressed hub flange","brass",(side*.063,0,0),(.090,.090,.069),orient,.063)
        for j in range(8):
            a=j*TAU/8;cy=math.cos(a);cz=math.sin(a)
            obj(w,"Hub lug","cylinder","steel",(side*.069,.066*cy,.066*cz),(.009,.009,.009),rot(Z,math.pi/2),6)
        for j in range(17):
            for tread in (-1,1):
                a=(j+.18*tread)*TAU/17;cy=math.cos(a);sz=math.sin(a)
                pivot=s.node("Tread pitch",w,(tread*.025,.142*cy,.142*sz),q=rot(X,a))
                obj(pivot,"Chevron tread block","box","rubberwall",(0,0,0),(.058,.011,.022),rot(Y,tread*.41))
                # One irregular pair of painted lugs provides a visible revolution
                # reference even when the repeated black tread aliases at speed.
                if j==13 or (j==14 and tread==side):
                    paint=PAINTS[4] if j==13 else "#f0dfb5"
                    obj(pivot,"Painted service chevron","box",paint,(0,.0062,0),(.054,.0037,.020),rot(Y,tread*.41))
        mark_angle=13*TAU/17
        cy,cz=math.cos(mark_angle),math.sin(mark_angle)
        obj(w,"Ivory hub witness","box","#f0dfb5",(side*.070,.059*cy,.059*cz),(.003,.058,.014),rot(X,mark_angle))
        obj(w,"Ochre shoulder witness","box",PAINTS[4],(side*.0557,.103*cy,.103*cz),(.004,.031,.019),rot(X,mark_angle))
        if i==0:
            for j in range(18):
                a=TAU*j/18
                obj(w,"Bottlecap crimp","box",col,(side*.058,.089*math.cos(a),.089*math.sin(a)),(.014,.012,.013),rot(X,a))

    # Rod ends, tiny spring hardware and linkage provide a readable underside.
    for side in (-1,1):
        s.bar("Tie rod",chassis,"steel",(side*.071,.174,.275),(side*.250,.158,.326),.010)
        for z in (-.302,.31):
            ell(chassis,"Ball joint","brass",(side*.236,.176,z),(.020,.019,.021),segments=14)
        rods(chassis,"Roll hoop","steel",[(side*.186,.216,-.273),(side*.175,.335,-.245),(side*.138,.365,-.208)],.012)
        for z in (-.18,-.06,.06,.18):
            ell(chassis,"Rivet head","steel",(side*.196,.267,z),(.009,.011,.010),segments=12)
        # A small ivory pinstripe following each cockpit sill.
        rods(chassis,"Coach stripe","#f0dfb5",[(side*.168,.296,-.22),(side*.184,.307,-.09),(side*.170,.331,.04),(side*.150,.327,.147)],.006,8)
    # Offset engine, rear pinion, toothed drive, coils, brake lamps, crash bar.
    obj(chassis,"Engine crankcase","box","iron",(0,.241,-.357),(.203,.111,.128))
    for j in range(6):
        obj(chassis,"Cooling fin","box","steel",(0,.257+j*.013,-.355),(.158-.006*j,.006,.093))
    obj(chassis,"Spark plug insulator","cylinder","#efe7d1",(.034,.345,-.352),(.014,.042,.014))
    rods(chassis,"Ignition lead","blackleather",[(.033,.371,-.351),(.064,.378,-.359),(.117,.322,-.34)],.006)
    for side in (-1,1):
        ell(chassis,"Brake lamp bezel","brass",(side*.149,.272,-.360),(.038,.029,.021))
        ell(chassis,"Ruby brake lamp","#a83724",(side*.149,.273,-.375),(.030,.022,.014))
    s.bar("Rear bumper crossbar",chassis,"steel",(-.204,.157,-.425),(.204,.157,-.425),.021)
    for side in (-1,1):
        s.bar("Rear bumper bracket",chassis,"iron",(side*.14,.16,-.315),(side*.16,.155,-.423),.014)
    for j in range(12):
        a=j*TAU/12;cy=math.cos(a);sz=math.sin(a)
        obj(chassis,"Sprocket tooth","box","brass",(.146,.19+.055*cy,-.312+.055*sz),(.014,.016,.016),rot(X,a))
    ring(chassis,"Drive sprocket","brass",(.145,.19,-.312),(.048,.048,.03),rot(Y,math.pi/2),.15)
    rods(chassis,"Drive chain","iron",[(.146,.24,-.311),(.146,.281,-.217),(.146,.241,-.21),(.146,.146,-.311)],.007)
    rods(chassis,"Exhaust manifold","brass",[(-.07,.303,-.339),(-.112,.310,-.354),(-.14,.277,-.371),(-.14,.276,-.422)],.016)
    obj(chassis,"Muffler","cylinder","iron",(-.14,.276,-.416),(.027,.088,.026),rot(X,math.pi/2))
    ring(chassis,"Rolled exhaust lip","steel",(-.14,.276,-.463),(.026,.026,.021),tube=.12)
    # Embossed enamel nose and vanity plate, painted individually for each driver.
    decal(chassis,"Nose racing roundel","plate%d"%i,(0,.351+(.035 if i in (3,4) else 0),.276),(.070,.054,.05),rot(X,-1.02))
    decal(chassis,"Rear number board","reg%d"%i,(0,.219,-.428),(.095,.034,.03),rot(Y,math.pi))
    for side in (-1,1):
        obj(chassis,"Nose stripe","box","#efdfb9",(side*.096,.332,.243),(.016,.007,.089),rot(X,.22))
    if i==0:
        # Threaded wooden body and its ratchet spool.
        for j in range(22):
            z=-.294+j*.017
            ring(chassis,"Wound flax thread","rope",(0,.235,z),(.186,.125,.12),tube=.028)
        obj(chassis,"Wooden spool lip","cylinder","oak",(0,.233,-.299),(.212,.023,.135),rot(X,math.pi/2))
        for side in (-1,1):
            s.bar("Hand-sewn number tab",chassis,"leather",(side*.132,.326,.15),(side*.157,.299,.246),.008)
    elif i==1:
        obj(chassis,"Cork bumper sleeve","cylinder","cork",(0,.225,.426),(.0715,.379,.0735),rot(Z,math.pi/2))
        for side in (-1,1):
            for z in (-.17,-.10,-.03,.04,.11):
                obj(chassis,"Louvered engine vent","box","iron",(side*.210,.268,z),(.009,.035,.022),rot(X,-.38))
            for x in (.09,.16):
                s.bar("Cork strap",chassis,"leather",(side*x,.17,.415),(side*x,.274,.445),.009)
    elif i==2:
        for side in (-1,1):
            for z in (-.25,.03,.25):
                for t in range(4):
                    ring(chassis,"Bound reed lashing","rope",(side*.205,.25,z+t*.009),(.042,.042,.09),tube=.09)
            # Helical reed suspension around the strut.
            for z in (-.304,.315):
                coil=[]
                for k in range(30):
                    a=k*TAU/6
                    coil.append((side*.220+.032*math.cos(a),.172+k*.0033,z+.032*math.sin(a)))
                rods(chassis,"Suspension helix","brass",coil,.0045,6)
    elif i in (3,4):
        # Seedpod strakes soften towards the wooden nose.
        for n in range(-2,3):
            x=n*.048
            rods(chassis,"Seedpod carapace rib","leafpod",[(x*.73,.299,-.208),(x,.353,-.11),(x,.373,.056),(x*.84,.356,.221),(x*.34,.300,.343)],.009)
        for side in (-1,1):
            for k in range(4):ring(chassis,"Axle bindings","rope",(side*(.188+.010*k),.151,-.305),(.049,.049,.09),rot(Y,math.pi/2),.08)
    if i==4:
        # Chestnut motor shell and ochre enamel fenders.
        for side in (-1,1):
            ell(chassis,"Ochre wheel fairing",col,(side*.221,.248,-.291),(.074,.071,.116))
            for j in range(5):
                rods(chassis,"Chestnut casing seam","leafpod",[(side*(.078+j*.016),.281,-.226),
                     (side*(.09+j*.019),.345,-.17),(side*(.068+j*.018),.36,.09)],.005)
    elif i==5:
        # Swept leaf fairings around a narrow crimson bonnet.
        for side in (-1,1):
            ell(chassis,"Foxglove running board",col,(side*.161,.239,.110),(.066,.055,.202),rot(Y,side*.21))
            tuft(chassis,"Swept rear stabilizer",col,(side*.187,.226,-.24),(.046,.139,.045),rot(X,-.70))
            rods(chassis,"Ivory racing flash","#f1dfb9",[(side*.163,.280,-.05),(side*.178,.298,.11),(side*.121,.302,.28)],.008)
    elif i==6:
        obj(chassis,"Armoured ram bumper","box","iron",(0,.223,.417),(.434,.083,.073))
        for x in (-.17,-.087,0,.087,.17):
            obj(chassis,"Ram rivet","cylinder","brass",(x,.226,.457),(.016,.013,.016),rot(X,math.pi/2),6)
        for side in (-1,1):
            for j in range(5):obj(chassis,"Hood louvre","box","iron",(side*.102,.317,.176+j*.021),(.090,.008,.009))
    elif i==7:
        for side in (-1,1):
            lamp=s.node("Searchlight assembly",chassis,(side*.146,.334,.307),q=rot(X,math.pi/2))
            obj(lamp,"Lamp barrel","cylinder","brass",(0,0,0),(.052,.063,.052))
            ell(lamp,"Headlight lens","headlamp",(0,.035,0),(.045,.013,.045))
            for k in (-1,0,1):
                s.bar("Lens guard",lamp,"iron",(k*.019,.046,-.033),(k*.019,.046,.033),.0028)
            rods(chassis,"Braided power line","blackleather",[(side*.142,.323,.25),(side*.16,.292,.13),(side*.153,.289,-.1)],.007)

    # Articulated driver rooted just above the seat.
    rig=s.node("Driver lean rig",chassis,(0,.338,-.075))
    if i==6:
        for side in (-1,1):
            ell(rig,"Broad canvas shoulder","jacket6",(side*.102,.159,-.001),(.075,.079,.085))
    ell(rig,"Shaped racing jacket","jacket%d"%i,(0,.108,-.005),(.133,.144,.106))
    ell(rig,"Right jacket panel","jacket%d"%i,(.053,.114,.058),(.071,.119,.061),rot(Z,-.04))
    ell(rig,"Left jacket panel","jacket%d"%i,(-.053,.114,.058),(.071,.119,.061),rot(Z,.04))
    for side in (-1,1):
        # Piped jacket seams and lapels.
        rods(rig,"Leather harness","leather",[(side*.091,.210,.062),(side*.071,.157,.103),(side*.05,.056,.094)],.013)
        rods(rig,"Harness stitch","stitch",[(side*.093,.203,.073),(side*.074,.158,.114),(side*.054,.064,.106)],.0018,6)
        ring(rig,"Square brass harness buckle","brass",(side*.068,.131,.109),(.018,.023,.011),tube=.15)
        ell(rig,"Shoulder gusset","jacket%d"%i,(side*.111,.163,.009),(.057,.054,.062))
        rods(rig,"Bent sleeve","jacket%d"%i,[(side*.119,.153,.018),(side*.146,.102,.071),(side*.122,.102,.111)],.038,16)
        ell(rig,"Glove cuff","leather",(side*.128,.105,.105),(.039,.037,.042))
        ell(rig,"Driving glove","blackleather",(side*.105,.117,.143),(.041,.035,.045),rot(Y,side*.18))
        for f in range(3):
            ell(rig,"Gloved finger","leather",(side*(.083+.015*f),.119,.168),(.009,.015,.021),rot(X,-.4),14)
    decal(rig,"Checker shoulder patch","checker",(-.140,.177,.048),(.026,.023,.01),rot(Y,-.9))
    decal(rig,"Stitched rear race patch","reg%d"%i,(0,.139,-.105),(.046,.028,.03),rot(Y,math.pi))
    rods(rig,"Brass zipper","brass",[(0,.026,.081),(0,.102,.119),(0,.193,.106)],.0036)
    for j in range(12):
        y=.046+j*.010;z=.095+.025*math.sin((y-.03)/.17*math.pi)
        obj(rig,"Interlocking zipper teeth","box","steel",((-.0017 if j%2 else .0017),y,z),(.007,.004,.004))
    ring(rig,"Zipper pull","brass",(.005,.168,.118),(.008,.013,.009),tube=.18)
    # Neck wraps stay visible directly behind the driver in the chase view.
    scarf="scarf" if i in (0,2) else "leather"
    ell(rig,"Woven neck wrap",scarf,(0,.218,-.000),(.111,.041,.095))
    ell(rig,"Scarf knot",scarf,(-.062,.211,-.084),(.043,.033,.035),rot(X,-.3))
    for j in (0,1):
        ell(rig,"Trailing scarf end",scarf,(-.058+.035*j,.179-.020*j,-.13-.012*j),(.031,.014,.072),rot(X,-.52+.14*j))

    face=s.node("Head rig",rig,(0,.363,.006))
    custom(face,"Sculpted cranium","Head shape %d"%i,head_shape(i),"head%d"%i,(0,0,0))
    # Plump muzzle pads taper into the bridge. Dark mouth & paired incisors read on close-up.
    ext=[0,.018,-.002,.003,.012,.036,.020,.041][i]
    smile=[1.35,.73,1.33,1.18,.99,1.12,.77,.97][i]
    ell(face,"Smile opening","#49312b",(0,-.060-.005*smile,.132+ext),(.043*smile,.016*smile,.018))
    if i in (0,2,3,5):
        ell(face,"Smile lower lip","#b37b73",(0,-.075,.145+ext),(.026*smile,.007,.0035),segments=16)
    for side in (-1,1):
        ell(face,"Incisor","#f4dfb9",(side*.007,-.062,.149+ext),(.006,.009,.004),segments=16)
        ell(face,"Cream muzzle",cream,(side*.034,-.037,.132+ext),(.055,.036,.043),rot(Z,-side*.15))
        ell(face,"Soft cheek",cream,(side*.094,-.038,.075),(.050,.040,.034),rot(Z,-side*.16))
        for j in range(7):
            z=.046+.007*j;y=-.046+.008*math.sin(j*.9)
            mat=cream if j in (1,2,4,5) else fur
            tuft(face,"Cheek fur layers",mat,(side*(.115+.0025*j),y,z),(.013,.032+.004*(j%3),.019),rot(Z,side*1.95))
    nosez=.172+ext
    ell(face,"Nose leather","blackleather" if i in (4,5,6) else "ear",(0,-.014,nosez),(.035,.023,.026),segments=32)
    for side in (-1,1):
        ell(face,"Nostril","#81504a",(side*.013,-.019,nosez+.025),(.006,.003,.0024),rot(Z,-side*.25),14)
        for j in range(4):
            py=-.036+.007*j;root=(side*(.083+.005*(j%2)),py,.143)
            ell(face,"Whisker follicle","#ad896d",root,(.003,.003,.002),segments=10)
            rods(face,"Curved whisker","#6e6255",[root,(side*.139,py+.004*(j-1),.147+.003*j),
                 (side*(.182+.008*(j%3)),py+.014*(j-1),.136+.006*j)],.00072,5)
        # Sclera, colored iris, pupil, upper lid and layered corneal reflections.
        expression=[(1.04,1.04),(.98,.83),(1.08,1.08),(1.03,.97),(.97,1.02),(1.05,.94),(.96,.82),(.75,.76)][i]
        eye=s.node("Eye socket",face,(side*.071,.030,.110+(.004 if i in (5,7) else 0)),q=rot(Y,side*.37),scale=(*expression,.85 if i==7 else 1))
        ell(eye,"Upper eye contour","#4f362b",(0,.005,-.004),(.044,.046,.021),rot(Z,-side*.06))
        ell(eye,"Warm sclera","#efdec3",(0,0,.004),(.043,.044,.024),segments=34)
        ell(eye,"Iris limbus","#38251f",(-side*.003,0,.025),(.032,.036,.012),segments=32)
        ell(eye,"Iris pigment","iris%d"%i,(-side*.004,.000,.030),(.026,.031,.010),segments=32)
        ell(eye,"Dark pupil","#231d19",(-side*.005,.001,.038),(.016,.021,.005),segments=28)
        ell(eye,"Window catchlight","#fff9e4",(-.008,.014,.043),(.009,.010,.0025),segments=16)
        ell(eye,"Secondary catchlight","#d6cfc0",(.010,-.009,.043),(.003,.004,.0015),segments=12)
        ell(face,"Expressive eyebrow",fur,(side*.086,.083,.107),(.042,.012,.010),rot(Z,side*(.27 if i==1 else .16)),22)
        # Dense ear backing, carved concave inner bell, fine marginal hair.
        ear=s.node("Ear pivot",face,(side*[.104,.100,.060,.096,.106,.091,.111,.113][i],[.096,.089,.119,.101,.083,.088,.083,.056][i],-.014),
                   q=rot(Z,-side*[.37,.45,.13,.22,.45,.19,.40,.5][i]))
        earL,earW=EAR_LENGTH[i],EAR_WIDTH[i]
        if i!=5:ell(ear,"Soft ear backing",fur,(0,earL*.50,-.023),(earW,earL*.51,.016),segments=32)
        custom(ear,"Rolled outer ear","Outer ear %d"%i,ear_shape(i),fur,(0,0,0))
        custom(ear,"Inner ear velvet","Inner ear %d"%i,ear_shape(i,True),"ear",(0,0,.010))
        for j in range(0 if i==5 else 6):
            a=.52+j*.48
            tuft(ear,"Ear edge fur",fur,(math.cos(a)*earW*.91,earL*(.5+.47*math.sin(a)),-.001),(.008,.009+(i==3)*.013,.009),rot(Z,-.4*math.cos(a)))
    # Strap crosses the back of the skull, goggles sit above the eyes.
    for j in range(24):
        a=(j+0)*TAU/24;b=(j+1)*TAU/24
        p1=(.139*math.sin(a),.083+.004*math.cos(a),.109*math.cos(a))
        p2=(.139*math.sin(b),.083+.004*math.cos(b),.109*math.cos(b))
        s.bar("Leather goggle strap",face,"leather",p1,p2,.015,12)
    for side in (-1,1):
        if i==7:
            ring(face,"Round gilt spectacles","brass",(side*.072,.031,.149),(.044,.044,.017),rot(Y,side*.23),.068)
            s.bar("Wire spectacle arm",face,"brass",(side*.11,.039,.135),(side*.146,.054,-.017),.0028)
            continue
        lens=s.node("Aviator goggle",face,(side*.058,.121,.071),q=rot(X,-.56))
        ell(lens,"Padded leather eyecup","leather",(0,0,0),(.064,.051,.031),rot(Z,-side*.11),32)
        ring(lens,"Antique brass goggle bezel","brass",(0,.001,.027),(.055,.041,.028),tube=.105)
        ell(lens,"Smoky glass","goldglass" if i==4 else "glass",(0,.001,.028),(.052,.038,.018),segments=32)
        ell(lens,"Glass highlight","#acb7a8",(-.019,.014,.043),(.019,.0038,.0018),rot(Z,.24),16)
    rods(face,"Goggle bridge","leather",[(-.015,.112,.117),(0,.119,.119),(.015,.112,.117)],.008)
    ring(face,"Strap buckle","brass",(.137,.084,-.023),(.016,.022,.012),rot(Y,math.pi/2),.19)
    for j in range(7):
        side=1 if j%2 else -1
        tuft(face,"Forelock",fur,(side*.009*j,.130+(.001*j),.035-.004*j),(.012,.033-.002*j,.021),rot(Z,side*.48))
    if i==1:
        # Scar is a fine, pale line breaking the brow fur on one side.
        rods(face,"Old brow scar","#b59988",[(.106,.090,.096),(.098,.077,.112),(.094,.068,.117)],.0022,6)
    if i==3:
        tail=s.node("Plume pivot",rig,(.033,.003,-.114),q=rot(Z,-.23))
        for j,(x,y,z,rx,ry,rz) in enumerate(((0,.035,-.025,.054,.079,.068),(.023,.122,-.071,.080,.115,.098),
             (.044,.242,-.092,.105,.137,.116),(.049,.341,-.067,.100,.100,.091),(.038,.390,-.026,.074,.065,.073))):
            ell(tail,"Squirrel plume curl",fur,(x,y,z),(rx,ry,rz),rot(X,.27*j-.31),34)
            for k in range(7):
                a=k*TAU/7+.25*j
                tuft(tail,"Layered tail fur","lightfur3" if (j+k)%11==0 else fur,
                     (x+math.cos(a)*rx*.87,y+.010,z+math.sin(a)*rz*.87),(.019,.047,.024),rot(Z,-.55*math.cos(a)))
    elif i==5:
        tail=s.node("Fox brush",rig,(.017,.015,-.102),q=rot(Z,-.50))
        for j,(x,y,z,rx,ry,rz) in enumerate(((0,.02,-.04,.042,.063,.052),(.015,.095,-.078,.062,.096,.075),
              (.029,.202,-.10,.076,.105,.089),(.030,.298,-.110,.070,.093,.077),(.027,.376,-.130,.052,.073,.062),(.010,.431,-.144,.027,.047,.028))):
            color=cream if j>=4 else fur
            ell(tail,"White brush tip" if j>=4 else "Fox tail",color,(x,y,z),(rx,ry,rz),rot(X,-.24),30)
            for k in range(5):
                a=k*TAU/5+j*.28
                tuft(tail,"Brush fur",color,(x+rx*.78*math.cos(a),y,z+rz*.8*math.sin(a)),(.019,.044,.021),rot(Z,-.39*math.cos(a)))
    elif i==4:
        ell(rig,"Hedgehog tail",fur,(.028,.055,-.137),(.021,.021,.043),rot(X,-.42),18)
        # Short tapered quills overlap in a swept hood, with pale horn tips.
        for row in range(7):
            phi=.48+row*.32
            for j in range(11):
                a=(j-5)*.34+.10*(row%2)
                xx=.158*math.sin(phi)*math.sin(a);yy=.150*math.cos(phi);zz=-.127*math.sin(phi)*math.cos(a)
                quill=s.node("Swept quill",face,(xx,yy,zz),q=rot(X,-1.01-row*.12))
                tuft(quill,"Quill shaft","quill",(0,0,0),(.014,.075+.005*(j%3),.023),rot(Z,-.4*math.sin(a)))
                tuft(quill,"Pale quill tip","#c4ab7c",(-.004*math.sin(a),.056,-.002),(.006,.023,.007),rot(Z,-.4*math.sin(a)))
    elif i==7:
        ell(rig,"Mole tail",fur,(.045,.049,-.142),(.015,.016,.054),rot(Y,-.68),18)
        lamp=s.node("Miner's headlamp",face,(0,.108,.110),q=rot(X,math.pi/2-.33))
        obj(lamp,"Brass searchlamp body","cylinder","brass",(0,0,0),(.056,.042,.056))
        ell(lamp,"Amber lens","headlamp",(0,.027,0),(.047,.014,.047))
        for side in (-1,1):
            ell(rig,"Digging paw","rosepaw",(side*.115,.105,.141),(.055,.037,.052))
            for j in range(4):
                ell(rig,"Velvet paw claw","#d8c4a7",(side*(.089+.015*j),.104,.181),(.006,.010,.022),rot(X,-.33),12)
    elif i==6:
        ell(rig,"Badger brush",fur,(.038,.044,-.144),(.044,.052,.089),rot(X,-.67))
        ell(rig,"Badger tail tip",cream,(.040,.078,-.202),(.029,.032,.048),rot(X,-.67))
    elif i==2:
        ell(rig,"Plush cottontail",cream,(0,.052,-.139),(.062,.067,.059),segments=32)
    else:
        from vehicle_rig import tapered_tail
        custom(rig,"Tapered tail","Tapered tail "+NAMES[i],tapered_tail(i),"ear",(0,0,0))
    # Tiller steering wheel, three spokes, central retaining nut and wheel wrap.
    s.bar("Steering column",chassis,"steel",(0,.281,.179),(0,.451,.097),.013)
    steering=s.node("Steering wheel rig",chassis,(0,.451,.100),q=rot(X,-.66))
    ring(steering,"Leather wrapped steering rim","blackleather",(0,0,0),(.104,.092,.105),tube=.119)
    for a in (0,TAU/3,2*TAU/3):
        s.bar("Steering spoke",steering,"steel",(0,0,0),(.098*math.sin(a),.088*math.cos(a),0),.008,10)
    ell(steering,"Steering hub","brass",(0,0,.002),(.024,.024,.012))
    for j in range(12):
        a=j*TAU/12;x=.104*math.cos(a);y=.092*math.sin(a)
        ell(steering,"Wheel binding","leather",(x,y,.006),(.010,.009,.008),segments=12)
    from vehicle_rig import rig_vehicle
    rig_vehicle(s,i,chassis,rig,face,steering,animated)
    return chassis
