"""Articulation shared by GLB driver assemblies and in-game skin palettes."""
import copy
import math

import numpy as np
from build_models import rot

NAMES=("chassis","rearLeft","rearRight","frontLeft","frontRight","torso","head","leftEar","rightEar",
       "tailBase","steering","leftGlove","rightGlove","scarf","tailMid","tailTip")
PARENTS=(-1,-1,-1,-1,-1,0,5,6,6,5,0,5,5,5,9,14)
LONG_TAILS=(
    ((0,.055,-.082),(-.048,.035,-.133),(-.154,.011,-.158),(-.217,-.012,-.214),
     (-.236,-.027,-.305),(-.181,-.027,-.379),(-.079,.003,-.423),(.018,.044,-.409),(.047,.083,-.373)),
    ((0,.058,-.081),(.063,.035,-.129),(.164,-.003,-.156),(.241,-.031,-.221),
     (.252,-.044,-.315),(.193,-.042,-.414),(.072,-.002,-.453),(-.038,.053,-.435),(-.104,.089,-.384),(-.137,.093,-.314)))


def smooth_path(anchors,steps=6):
    pts=np.asarray(anchors,float);out=[]
    for j in range(len(pts)-1):
        a,b,c,d=pts[max(j-1,0)],pts[j],pts[j+1],pts[min(j+2,len(pts)-1)]
        for k in range(steps):
            t=k/steps
            out.append(.5*(2*b+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t**3))
    return np.array(out+[pts[-1]])


def tapered_tail(i):
    points=smooth_path(LONG_TAILS[i]);sides=14
    length=np.r_[0,np.linalg.norm(np.diff(points,axis=0),axis=1).cumsum()];length/=length[-1]
    tangent=np.gradient(points,axis=0);tangent/=np.linalg.norm(tangent,axis=1)[:,None]
    p,n,uv,idx=[],[],[],[]
    for j,(center,t,axis) in enumerate(zip(points,length,tangent)):
        side=np.cross(axis,[0,1,0]);side/=np.linalg.norm(side);up=np.cross(side,axis)
        radius=(.019 if i==0 else .022)*(1-t)**.59+.0014
        radius*=1+.021*math.sin(t*math.pi*66)
        for k in range(sides+1):
            a=math.tau*k/sides;normal=math.cos(a)*side+math.sin(a)*up
            p.append((center+radius*normal).tolist());n.append(normal.tolist());uv.append((k/sides,t))
            if j and k:
                v=j*(sides+1)+k;o=v-sides-2;idx.extend((o,v-1,o+1,o+1,v-1,v))
    return p,n,uv,idx


def transform(node):
    x,y,z,w=node.get("rotation",(0,0,0,1))
    r=np.array([[1-2*y*y-2*z*z,2*x*y-2*z*w,2*x*z+2*y*w],
                [2*x*y+2*z*w,1-2*x*x-2*z*z,2*y*z-2*x*w],
                [2*x*z-2*y*w,2*y*z+2*x*w,1-2*x*x-2*y*y]])
    m=np.eye(4);m[:3,:3]=r@np.diag(node.get("scale",[1,1,1]));m[:3,3]=node.get("translation",[0,0,0])
    return m


def world_matrices(s,root):
    result={}
    def walk(n,world):
        m=world@transform(s.g["nodes"][n]);result[n]=m
        for child in s.g["nodes"][n].get("children",[]):walk(child,m)
    walk(root,np.eye(4));return result


def tail_weights(points,path):
    # Project onto the nearest centerline segment in the bind pose. The two
    # neighboring joints interpolate continuously across every visible strand.
    segments=np.diff(path,axis=0)
    lengths=np.linalg.norm(segments,axis=1);sums=np.r_[0,lengths.cumsum()]
    best=np.full(len(points),np.inf);distance=np.zeros(len(points))
    for j,seg in enumerate(segments):
        t=np.clip((points-path[j])@seg/(lengths[j]**2),0,1)
        nearest=path[j]+t[:,None]*seg
        d=np.sum((points-nearest)**2,axis=1);mask=d<best
        best[mask]=d[mask];distance[mask]=sums[j]+t[mask]*lengths[j]
    unit=np.clip(3*distance/sums[-1],0,3)
    segment=np.minimum(np.floor(unit).astype(int),2)
    weight=unit-segment
    weight=weight*weight*(3-2*weight)
    ids=np.asarray((9,14,15))[segment]
    return ids,weight,segment


def at_length(path,f):
    accum=np.r_[0,np.linalg.norm(np.diff(path,axis=0),axis=1).cumsum()]
    return np.asarray([np.interp(f*accum[-1],accum,path[:,k]) for k in range(3)])


def rotate(q,a):
    """Hamilton product for a local rest orientation followed by a joint motion."""
    x,y,z,w=q;xx,yy,zz,ww=a
    return [w*xx+x*ww+y*zz-z*yy,w*yy-x*zz+y*ww+z*xx,w*zz+x*yy-y*xx+z*ww,w*ww-x*xx-y*yy-z*zz]


def rig_vehicle(s,i,root,torso,head,steering,animate):
    nodes=s.g["nodes"];bones=[None]*16
    def tag(node,b):
        nodes[node].setdefault("extras",{})["rigBone"]=b;bones[b]=node
    def direct(node):
        return list(nodes[node].get("children",[]))
    def cluster(at,name,offset,members):
        group=s.node(name,at,offset);selected=set(members)
        nodes[at]["children"]=[n for n in nodes[at]["children"] if n not in selected]
        for n in members:
            child=nodes[n];child["translation"]=(np.asarray(child.get("translation",(0,0,0)))-offset).tolist()
            nodes[group].setdefault("children",[]).append(n)
        return group
    original=direct(root)
    wheels=[n for n in original if nodes[n]["name"] in ("Steer pivot","Rear hub")]
    chassis=cluster(root,"Suspended chassis",np.array((0,.222,-.008)),[n for n in original if n not in wheels])
    tag(chassis,0);tag(torso,5);tag(head,6);tag(steering,10)
    spins=[];front=[]
    for n in wheels:
        x,y,z=nodes[n]["translation"];b=(3 if z>0 else 1)+(x>0)
        spin=cluster(n,NAMES[b]+" wheel spin",np.zeros(3),direct(n));tag(spin,b);spins.append(spin)
        if z>0:front.append(n)
    for n in direct(head):
        if nodes[n]["name"]=="Ear pivot":tag(n,7+(nodes[n]["translation"][0]>0))
    hands={"Driving glove","Glove cuff","Gloved finger","Digging paw","Velvet paw claw"}
    for side in (-1,1):
        selected=[]
        for n in direct(torso):
            node=nodes[n];x,y,z=node.get("translation",(0,0,0))
            if side*x>0 and (node["name"] in hands or (node["name"]=="Bent sleeve" and z>.072)):selected.append(n)
        tag(cluster(torso,("Left" if side<0 else "Right")+" forearm and glove",np.array((side*.146,.102,.071)),selected),11+(side>0))
    scarf=cluster(torso,"Scarf flutter",np.array((-.062,.211,-.084)),[n for n in direct(torso) if nodes[n]["name"] in ("Scarf knot","Trailing scarf end")]);tag(scarf,13)
    # Locate each tail's original authoring frame. The plume & brush have an
    # offset, rotated basis, while the smaller tails are modeled in seat space.
    tail_roots=[n for n in direct(torso) if nodes[n]["name"] in
                ("Tapered tail","Plume pivot","Fox brush","Badger brush","Badger tail tip","Plush cottontail","Hedgehog tail","Mole tail")]
    frames=world_matrices(s,root)
    reference=tail_roots[0] if i in (3,5) else torso
    if i in (0,1):points=smooth_path(LONG_TAILS[i],3)
    elif i==2:points=np.array(((0,.047,-.085),(0,.048,-.119),(0,.054,-.155),(0,.065,-.198)))
    elif i==3:points=np.array(((0,0,.006),(0,.035,-.025),(.024,.125,-.071),(.044,.242,-.092),(.049,.341,-.067),(.038,.445,-.006)))
    elif i==4:points=np.array(((.018,.04,-.103),(.029,.052,-.138),(.038,.078,-.171)))
    elif i==5:points=np.array(((0,0,0),(0,.02,-.04),(.015,.095,-.078),(.029,.202,-.10),(.03,.298,-.11),(.027,.376,-.13),(.004,.475,-.152)))
    elif i==6:points=np.array(((.019,.026,-.084),(.03,.038,-.124),(.038,.062,-.17),(.04,.081,-.216),(.03,.093,-.247)))
    else:points=np.array(((.01,.048,-.095),(.025,.042,-.126),(.05,.041,-.152),(.079,.059,-.179)))
    frame=frames[reference];path=points@frame[:3,:3].T+frame[:3,3];s.tail_path=path
    parent=torso;org=frames[torso][:3,3]
    for b,fraction in ((9,0),(14,1/3),(15,2/3)):
        pivot=at_length(path,fraction)
        joint=s.node(NAMES[b],parent,pivot-org);tag(joint,b)
        parent=joint;org=pivot
    assert all(n is not None for n in bones)
    frames=world_matrices(s,root)
    joint_ids=[torso,bones[9],bones[14],bones[15]]
    def skin(n):
        child=nodes[n];child.setdefault("extras",{})["tailDeform"]=True
        if "mesh" in child:
            mesh=copy.deepcopy(s.g["meshes"][child["mesh"]]);p=mesh["primitives"][0];attr=p["attributes"]
            acc=s.g["accessors"][attr["POSITION"]];bv=s.g["bufferViews"][acc["bufferView"]]
            pts=np.frombuffer(s.buf,dtype='<f4',count=acc["count"]*3,offset=bv["byteOffset"]).reshape((-1,3)).copy()
            m=frames[n];points=pts@m[:3,:3].T+m[:3,3];_,weight,seg=tail_weights(points,path)
            joints=np.zeros((len(pts),4),dtype=np.uint16);weights=np.zeros((len(pts),4))
            joints[:,0]=seg;joints[:,1]=seg+1;weights[:,0]=1-weight;weights[:,1]=weight
            attr["JOINTS_0"]=s.accessor(joints,"VEC4",5123,34962);attr["WEIGHTS_0"]=s.accessor(weights,"VEC4",target=34962)
            child["mesh"]=len(s.g["meshes"]);s.g["meshes"].append(mesh)
            mats=[(np.linalg.inv(frames[j])@m).T.flatten() for j in joint_ids]
            bind=s.accessor(mats,"MAT4")
            skins=s.g.setdefault("skins",[]);child["skin"]=len(skins)
            skins.append({"name":"Tail · continuous bend","joints":joint_ids,"skeleton":torso,"inverseBindMatrices":bind})
        for c in direct(n):skin(c)
    for n in tail_roots:skin(n)
    s.rig_data={"names":NAMES,"parents":PARENTS,"pivots":[(frames[n][:3,3]*2).round(7).tolist() for n in bones],
                "wheelRadius":.29,"steeringAxis":[0,math.sin(.66),math.cos(.66)],"tailLength":float(np.linalg.norm(np.diff(path,axis=0),axis=1).sum()*2)}
    if not animate:return
    def rotations(n,axis,values,times):
        q=nodes[n].get("rotation",(0,0,0,1))
        return (n,"rotation",times,[rotate(q,rot(axis,v)) for v in values])
    x=(1,0,0);y=(0,1,0);z=(0,0,1)
    times=[0,.25,.50,.75,1.]
    s.anim("Wheel revolution", [rotations(n,x,[j*math.pi/2 for j in range(5)],times) for n in spins])
    def turn(seq,multiplier):return [v*multiplier for v in seq]
    direction=[0,.76,1.,-.82,0]
    tracks=[rotations(n,y,turn(direction,.44),times) for n in front]
    tracks+=[rotations(n,axis,turn(direction,strength),times) for n,axis,strength in
             ((chassis,z,-.065),(torso,z,-.15),(head,y,.23),(steering,z,-.64),(bones[11],z,-.085),(bones[12],z,-.085),
              (bones[7],z,.085),(bones[8],z,.065),(bones[9],y,-.19),(bones[14],y,-.34),(bones[15],y,-.45),(scarf,y,.18))]
    s.anim("Steer and drift",tracks)
    for label,seq in (("Impact",[0,1,-.45,.19,0]),("Landing",[-.65,1,-.32,.12,0]),("Ability",[0,-.60,.38,-.15,0]),("Victory",[0,-.72,.12,-.6,0])):
        times=[0,.105,.24,.41,.63]
        loc=nodes[chassis]["translation"]
        tracks=[(chassis,"translation",times,[[loc[0],loc[1]-.046*v,loc[2]] for v in seq])]
        tracks.extend(rotations(n,ax,turn(seq,amp),times) for n,ax,amp in
                      ((torso,x,-.18),(head,x,.21),(bones[7],x,-.20),(bones[8],x,-.16),
                       (bones[9],y,.16),(bones[14],y,.23),(bones[15],y,.35),(scarf,x,-.36)))
        s.anim(label,tracks)
